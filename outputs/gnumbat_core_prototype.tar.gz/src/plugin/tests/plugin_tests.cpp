// Plugin-level tests (no DAW needed):
//   * processor: transparent pass-through, transport tracking, capture by timeline / last-N / loop, coverage, state
//   * UI: editor construction, bank filtering/sorting/selection, map geometry, Bake flow through the real dialog
//   * --snapshot <dir>: renders PNGs of the terminal UI
//   * --interop-write <lib> / --interop-verify <lib>: Bakes created through the plugin path, processed by the Python worker
#include <juce_audio_utils/juce_audio_utils.h>
#include "../plugin/PluginProcessor.h"
#include "../plugin/PluginEditor.h"
#include "../plugin/ui/NotationCard.h"
#include "../core/JsonIo.h"
#include "../core/Ids.h"
#include "../core/MapData.h"
#include "../core/NotationProfile.h"
#include <cstdlib>
#include <iostream>

using namespace gnumbat;
using juce::String;
using juce::var;

static void setEnv (const char* k, const String& v)
{
   #if JUCE_WINDOWS
    _putenv_s (k, v.toRawUTF8());
   #else
    ::setenv (k, v.toRawUTF8(), 1);
   #endif
}

static int g_checks = 0, g_fail = 0;
#define CHECK(cond) do { ++g_checks; if (! (cond)) { ++g_fail; std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << "  " << #cond << "\n"; } } while (0)
#define CHECK_MSG(cond, msg) do { ++g_checks; if (! (cond)) { ++g_fail; std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << "  " << #cond << "  -- " << String (msg).toRawUTF8() << "\n"; } } while (0)

// ---------------------------------------------------------------------------------------------------- fake host
struct FakeHost : juce::AudioPlayHead
{
    bool present = true, playing = true, looping = false, hasLoop = false;
    double bpm = 120.0, ppqAt0 = 0.0;
    int num = 4, den = 4;
    juce::int64 timeSamples = 0;
    double sampleRate = 48000.0;
    double loopStart = 0.0, loopEnd = 0.0;

    juce::Optional<PositionInfo> getPosition() const override
    {
        if (! present) return {};
        PositionInfo p;
        p.setIsPlaying (playing);
        p.setIsRecording (false);
        p.setIsLooping (looping);
        p.setBpm (bpm);
        p.setTimeSignature (TimeSignature { num, den });
        p.setTimeInSamples (timeSamples);
        p.setPpqPosition (ppqAt0 + (double) timeSamples / sampleRate * bpm / 60.0);
        if (hasLoop) p.setLoopPoints (LoopPoints { loopStart, loopEnd });
        return p;
    }
};

// Sample value is a pure function of (channel, timeline position): whatever order audio arrives in, a captured
// range can be verified sample-exactly against it.
static float valueAt (int ch, juce::int64 t) { return (float) ((t * 7 + ch * 13) % 20011) / 20011.0f - 0.5f; }

static void run (GnumbatProcessor& p, FakeHost* host, juce::int64 from, juce::int64 count, int block = 512, int channels = 2,
                 std::vector<std::vector<float>>* outCopy = nullptr)
{
    juce::AudioBuffer<float> buf (channels, block);
    juce::MidiBuffer midi;
    for (juce::int64 pos = 0; pos < count; pos += block)
    {
        const int n = (int) std::min<juce::int64> (block, count - pos);
        buf.setSize (channels, n, false, false, true);
        if (host != nullptr) host->timeSamples = from + pos;
        for (int c = 0; c < channels; ++c)
            for (int i = 0; i < n; ++i) buf.setSample (c, i, valueAt (c, from + pos + i));
        p.processBlock (buf, midi);
        if (outCopy != nullptr)
            for (int c = 0; c < channels; ++c)
                for (int i = 0; i < n; ++i) (*outCopy)[(size_t) c].push_back (buf.getSample (c, i));
    }
}

static bool matchesRange (const PreparedCapture& pc, juce::int64 start)
{
    if (pc.bake.audio.channels.empty()) return false;
    for (size_t c = 0; c < pc.bake.audio.channels.size(); ++c)
        for (size_t i = 0; i < pc.bake.audio.channels[c].size(); i += 37)
            if (pc.bake.audio.channels[c][i] != valueAt ((int) c, start + (juce::int64) i)) return false;
    return true;
}

static juce::File tempDir (const String& n)
{
    auto d = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("gnumbat_pt_" + n + "_" + String::toHexString (juce::Random::getSystemRandom().nextInt()));
    d.createDirectory();
    return d;
}

// ---------------------------------------------------------------------------------------------------- processor
static void testProcessor()
{
    GnumbatProcessor p;
    FakeHost host;
    p.setPlayHead (&host);
    p.setRateAndBufferSizeDetails (48000.0, 512);
    p.prepareToPlay (48000.0, 512);

    CHECK (! p.transport().valid);
    CHECK (! p.prepareCapture (p.plan).ok);                       // nothing has flowed yet: a clear message, not a crash
    CHECK (p.prepareCapture (p.plan).problem.isNotEmpty());

    // ---- transparent pass-through, bit-exact
    std::vector<std::vector<float>> out (2);
    run (p, &host, 0, 48000 * 10, 512, 2, &out);                  // 10 s at 120 bpm 4/4 = 5 bars
    bool exact = out[0].size() == 480000;
    for (size_t i = 0; exact && i < out[0].size(); ++i) exact = out[0][i] == valueAt (0, (juce::int64) i) && out[1][i] == valueAt (1, (juce::int64) i);
    CHECK (exact);

    // ---- transport mailbox
    auto t = p.transport();
    CHECK (t.valid && t.hostTimeline && t.playing);
    CHECK (std::abs (t.bpm - 120.0) < 1e-9 && t.tsNum == 4 && t.tsDen == 4);
    CHECK (t.samples == 480000);                                  // "now" = end of the last block
    CHECK (std::abs (t.ppq - 20.0) < 1e-6);                       // 10 s * 2 beats/s
    CHECK (t.written == 480000);

    // ---- last N bars: 2 bars * 4 beats * 0.5 s = 4 s
    p.plan.mode = CapturePlan::Mode::lastBars;
    p.plan.bars = 2.0;
    auto pc = p.prepareCapture (p.plan);
    CHECK_MSG (pc.ok, pc.problem);
    CHECK (pc.bake.audio.frames() == 4 * 48000 && pc.bake.audio.numChannels() == 2);
    CHECK (std::abs (pc.coverage - 1.0) < 1e-9 && pc.bake.capture.complete);
    CHECK (matchesRange (pc, 480000 - 4 * 48000));
    CHECK (pc.bake.capture.hasTimeline && pc.bake.capture.startSample == 480000 - 4 * 48000 && pc.bake.capture.endSample == 480000);
    CHECK (pc.bake.capture.tempoBpm == 120.0 && pc.bake.capture.timeSigNum == 4 && pc.bake.capture.mode == "last_bars");
    CHECK (pc.bake.capture.hostName.isNotEmpty() && pc.bake.capture.session.isNotEmpty());

    // ---- range by timeline
    p.plan.mode = CapturePlan::Mode::range;
    p.plan.in = { 96000, 4.0, true };
    p.plan.out = { 192000, 8.0, true };
    pc = p.prepareCapture (p.plan);
    CHECK_MSG (pc.ok, pc.problem);
    CHECK (pc.bake.audio.frames() == 96000 && matchesRange (pc, 96000));
    CHECK (pc.bake.capture.startSample == 96000 && pc.bake.capture.hasPpq && std::abs (pc.bake.capture.startPpq - 4.0) < 1e-9);
    CHECK (std::abs (p.coverageOf (p.plan.in, p.plan.out) - 1.0) < 1e-9);

    // ---- range never played: partial / none, clearly reported
    p.plan.in = { 480000, 20.0, true };  p.plan.out = { 480000 + 96000, 24.0, true };
    pc = p.prepareCapture (p.plan);
    CHECK (! pc.ok && pc.problem.contains ("None of that range"));
    run (p, &host, 480000, 48000, 512);                                       // play only the first second of that range
    pc = p.prepareCapture (p.plan);
    CHECK_MSG (pc.ok, pc.problem);
    CHECK (std::abs (pc.coverage - 0.5) < 0.01 && ! pc.bake.capture.complete);
    CHECK (std::abs (p.coverageOf (p.plan.in, p.plan.out) - 0.5) < 0.01);
    CHECK (pc.summary.contains ("50 %"));

    // ---- inverted / unset markers
    p.plan.in = { 200000, 0, false };  p.plan.out = { 100000, 0, false };
    CHECK (! p.prepareCapture (p.plan).ok);
    p.plan.in = {}; p.plan.out = {};
    CHECK (! p.prepareCapture (p.plan).ok);

    // ---- loop: the host wraps back to bar 2 three times; the newest pass wins and a range spanning passes is complete
    {
        GnumbatProcessor q;  FakeHost h;  q.setPlayHead (&h);
        q.setRateAndBufferSizeDetails (48000.0, 512);  q.prepareToPlay (48000.0, 512);
        for (int pass = 0; pass < 3; ++pass) run (q, &h, 48000, 96000, 512);         // loop = samples 48000..144000
        h.hasLoop = true; h.looping = true; h.loopStart = 2.0; h.loopEnd = 6.0;      // ppq 2..6 = 1 s..3 s at 120 bpm = samples 48000..144000
        h.timeSamples = 144000;
        run (q, &h, 144000, 512, 512);                                                // one more block so the mailbox carries the loop points
        q.plan.mode = CapturePlan::Mode::loop;
        auto lc = q.prepareCapture (q.plan);
        CHECK_MSG (lc.ok, lc.problem);
        CHECK (lc.bake.audio.frames() == 96000 && std::abs (lc.coverage - 1.0) < 1e-6);
        CHECK (matchesRange (lc, 48000));
        Marker a, b;
        CHECK (q.loopMarkers (a, b) && b.sample > a.sample && std::abs ((double) (b.sample - a.sample) - 96000.0) < 2.0);
    }

    // ---- stopped transport: audio still flows (live monitoring) but is not timeline-addressable
    {
        GnumbatProcessor q;  FakeHost h;  h.playing = false;  q.setPlayHead (&h);
        q.setRateAndBufferSizeDetails (48000.0, 512);  q.prepareToPlay (48000.0, 512);
        run (q, &h, 1000, 96000, 512);
        CHECK (! q.transport().playing);
        q.plan.mode = CapturePlan::Mode::range;  q.plan.in = { 1000, 0, false };  q.plan.out = { 50000, 0, false };
        CHECK (! q.prepareCapture (q.plan).ok);
        q.plan.mode = CapturePlan::Mode::lastSeconds;  q.plan.seconds = 1.0;
        auto lc = q.prepareCapture (q.plan);
        CHECK (lc.ok && lc.bake.audio.frames() == 48000);
        CHECK (! lc.bake.capture.hasTimeline);                                        // no timeline claimed for un-addressable audio
    }

    // ---- no play head at all (standalone / minimal hosts): own counter keeps RANGE working
    {
        GnumbatProcessor q;
        q.setRateAndBufferSizeDetails (44100.0, 256);  q.prepareToPlay (44100.0, 256);
        run (q, nullptr, 0, 44100 * 3, 256);
        CHECK (q.transport().valid && ! q.transport().hostTimeline);
        auto now = q.markerNow();
        CHECK (now.isSet() && now.sample >= 44100 * 3 - 256);
        q.plan.mode = CapturePlan::Mode::range;
        q.plan.in = { 44100, 0, false };  q.plan.out = { 44100 * 2, 0, false };
        auto rc = q.prepareCapture (q.plan);
        CHECK_MSG (rc.ok, rc.problem);
        CHECK (rc.bake.audio.frames() == 44100 && ! rc.bake.capture.hasTimeline);
        CHECK (matchesRange (rc, 44100));
    }

    // ---- mono
    {
        GnumbatProcessor q;
        q.setPlayHead (&host);
        q.setPlayConfigDetails (1, 1, 48000.0, 512);
        q.prepareToPlay (48000.0, 512);
        run (q, &host, 0, 48000, 512, 1);
        q.plan.mode = CapturePlan::Mode::lastSeconds;  q.plan.seconds = 0.5;
        auto mc = q.prepareCapture (q.plan);
        CHECK (mc.ok && mc.bake.audio.numChannels() == 1);
    }

    // ---- prepareToPlay churn: same config keeps the audio; a new sample rate legitimately starts over
    {
        const auto before = p.ring().totalWritten();
        p.prepareToPlay (48000.0, 256);
        CHECK (p.ring().totalWritten() == before);
        p.prepareToPlay (44100.0, 256);
        CHECK (p.ring().totalWritten() == 0);
    }

    // ---- state: markers + ui prefs survive; audio is never in the project file; garbage is ignored
    {
        GnumbatProcessor a;
        a.plan.mode = CapturePlan::Mode::range;  a.plan.in = { 12345, 3.5, true };  a.plan.out = { 99999, 9.5, true };  a.plan.bars = 8;  a.plan.seconds = 7.5;
        a.setUiState ("tab", "map");  a.setUiState ("search", "riser");
        juce::MemoryBlock mb;
        a.getStateInformation (mb);
        CHECK (mb.getSize() < 4096);
        GnumbatProcessor b;
        b.setStateInformation (mb.getData(), (int) mb.getSize());
        CHECK (b.plan.mode == CapturePlan::Mode::range && b.plan.in.sample == 12345 && b.plan.out.sample == 99999 && b.plan.in.hasPpq);
        CHECK (std::abs (b.plan.bars - 8.0) < 1e-9 && std::abs (b.plan.seconds - 7.5) < 1e-9);
        CHECK (b.getUiState ("tab").toString() == "map" && b.getUiState ("search").toString() == "riser");
        GnumbatProcessor c;
        const char junk[] = "not json at all";
        c.setStateInformation (junk, (int) sizeof (junk));
        CHECK (c.plan.mode == CapturePlan::Mode::lastBars);
        const char other[] = "{\"schema\":\"someone.else/1\",\"plan\":{\"mode\":\"range\"}}";
        c.setStateInformation (other, (int) sizeof (other) - 1);
        CHECK (c.plan.mode == CapturePlan::Mode::lastBars);
    }

    // ---- bus layouts: transparent tap, mono or stereo only
    {
        juce::AudioProcessor::BusesLayout l;
        l.inputBuses.add (juce::AudioChannelSet::stereo());  l.outputBuses.add (juce::AudioChannelSet::stereo());
        CHECK (p.isBusesLayoutSupported (l));
        l.outputBuses.set (0, juce::AudioChannelSet::mono());
        CHECK (! p.isBusesLayoutSupported (l));
        l.inputBuses.set (0, juce::AudioChannelSet::create5point1());  l.outputBuses.set (0, juce::AudioChannelSet::create5point1());
        CHECK (! p.isBusesLayoutSupported (l));
    }

    // ---- marker text round trip
    {
        TransportSnapshot ts;  ts.hasPpq = true;  ts.bpm = 120;  ts.tsNum = 4;  ts.tsDen = 4;  ts.sampleRate = 48000;
        Marker m { 96000, 4.0, true };
        auto txt = ui::CapturePanel::formatMarker (m, ts);
        CHECK (txt == "2|1.00");                                    // ppq 4 = bar 2 beat 1
        Marker now { 480000, 20.0, true }, parsed;
        CHECK (ui::CapturePanel::parseMarker (txt, now, ts, parsed) && parsed.sample == 96000);
        CHECK (ui::CapturePanel::parseMarker ("0:02.5", now, ts, parsed) && parsed.sample == 120000);
        CHECK (ui::CapturePanel::parseMarker ("3.25", now, ts, parsed) && parsed.sample == 156000);
        CHECK (! ui::CapturePanel::parseMarker ("bar two", { }, ts, parsed));
        ts.hasPpq = false;
        CHECK (ui::CapturePanel::formatMarker ({ 96000, 0, false }, ts) == "0:02.000");
    }
}

// ---------------------------------------------------------------------------------------------------- shared fixtures for UI
struct Env
{
    juce::File dir = tempDir ("env");
    juce::File lib = dir.getChildFile ("lib");
    Env()
    {
        setEnv ("GNUMBAT_SETTINGS", dir.getChildFile ("settings.json").getFullPathName());
        setEnv ("GNUMBAT_LIBRARY", lib.getFullPathName());
        setEnv ("GNUMBAT_AUTOSTART", "0");
    }
    ~Env() { dir.deleteRecursively(); }
};

static void pumpMessages (int ms)
{
    juce::MessageManager::getInstance()->runDispatchLoopUntil (ms);
}

static void fillDemo (Library& lib, int n, bool withTempo = true)
{
    static const char* words[] = { "rise", "fall", "hits", "drone", "metallic", "riser tension", "dark drone", "bright hits" };
    for (int i = 0; i < n; ++i)
    {
        NewBake nb;
        nb.audio.sampleRate = 44100.0;
        nb.audio.channels.assign (2, std::vector<float> (44100 * 2));
        for (size_t k = 0; k < nb.audio.channels[0].size(); ++k)
            nb.audio.channels[0][k] = nb.audio.channels[1][k] = 0.4f * std::sin ((float) k * 0.01f * (float) (1 + i % 7));
        nb.rawNotation = String (words[i % 8]) + (withTempo && i % 3 == 0 ? "-" + String (100 + i) + " BPM" : String());
        nb.profile = withTempo ? notation::builtinProfile ("np_musical_dash") : var();
        nb.capture.hostName = "test"; nb.capture.tempoBpm = 100 + i;
        nb.submit = false;
        String id;
        lib.createBake (nb, id);
    }
}

// ---------------------------------------------------------------------------------------------------- UI
static void testUi()
{
    Env env;
    Library::init (env.lib);
    Library lib (env.lib);
    fillDemo (lib, 24);

    GnumbatProcessor proc;
    proc.setRateAndBufferSizeDetails (48000.0, 512);
    proc.prepareToPlay (48000.0, 512);
    FakeHost host;
    proc.setPlayHead (&host);
    run (proc, &host, 0, 48000 * 12, 512);

    std::unique_ptr<juce::AudioProcessorEditor> ed (proc.createEditor());
    auto* editor = dynamic_cast<GnumbatEditor*> (ed.get());
    CHECK (editor != nullptr);
    if (editor == nullptr) return;
    editor->setSize (1200, 800);
    auto& model = editor->appModel();
    CHECK (model.hasLibrary());
    CHECK (model.rows().size() == 24 && model.visible().size() == 24);

    // ---- search + chips
    model.setSearch ("drone");
    const auto droneCount = model.visible().size();
    CHECK (droneCount > 0 && droneCount < 24);
    for (int i : model.visible()) CHECK (json::getString (model.rows()[(size_t) i].view, "notation").containsIgnoreCase ("drone"));
    model.setSearch ({});
    model.setChips ({ filter::leaf ("fields/tempo", "between", var (juce::Array<var> { 100, 110 })) });
    CHECK (model.visible().size() > 0 && model.visible().size() < 24);
    for (int i : model.visible()) { auto tv = json::getNumber (model.rows()[(size_t) i].view, "fields/tempo"); CHECK (tv >= 100 && tv <= 110); }
    model.setChips ({ filter::leaf ("fields/tempo", "exists", false) });
    CHECK (model.visible().size() > 0);
    model.setChips ({});
    CHECK (model.visible().size() == 24);

    // ---- sorting
    model.setSort ("notation", true);
    for (size_t i = 1; i < model.visible().size(); ++i)
        CHECK (json::getString (model.rows()[(size_t) model.visible()[i - 1]].view, "notation").toLowerCase() <= json::getString (model.rows()[(size_t) model.visible()[i]].view, "notation").toLowerCase());
    model.setSort ("created", false);
    CHECK (model.rows()[(size_t) model.visible().front()].id > model.rows()[(size_t) model.visible().back()].id);

    // ---- selection + edit through the model (what the inspector/bank buttons call)
    const auto id0 = model.rows()[0].id, id1 = model.rows()[1].id;
    model.setSelection ({ id0, id1 }, id1);
    CHECK (model.selection().size() == 2 && model.primary() == id1);
    SemanticEdit e;  e.addTags.add ("favourite");  e.addGroups.add ("keepers");
    CHECK (model.editSemantic ({ id0, id1 }, e).isEmpty());
    CHECK (json::getStrings (model.rowById (id0)->view, "tags").contains ("favourite"));
    CHECK (json::getStrings (model.rowById (id1)->view, "groups").contains ("keepers"));
    CHECK (model.relatedIds ("group", id0).size() == 2);

    // ---- trash + undo
    CHECK (model.trash ({ id1 }).isEmpty());
    CHECK (model.rows().size() == 23 && model.rowById (id1) == nullptr && ! model.selection().contains (id1));
    CHECK (model.canUndoTrash());
    CHECK (model.undoTrash().isEmpty());
    CHECK (model.rows().size() == 24 && model.rowById (id1) != nullptr);

    // ---- datasets
    CHECK (model.createDatasetWith ("test set", { id0, id1 }).isEmpty());
    CHECK (model.snapshot().datasets.size() == 1 && model.snapshot().datasets[0].members == 2);
    CHECK (JobSubmitter (env.lib).counts().pending >= 1);                // reindex queued for the worker

    // ---- worker absence is visible, and reprocess queues jobs
    CHECK (! model.snapshot().worker.alive);
    CHECK (model.reprocess ({ id0 }, "all").isEmpty());
    CHECK (JobSubmitter (env.lib).counts().pending >= 2);

    // ---- paint everything without crashing (bank, inspector single/multi/none, map without map)
    for (int sel = 0; sel < 3; ++sel)
    {
        model.setSelection (sel == 0 ? juce::StringArray() : sel == 1 ? juce::StringArray { id0 } : juce::StringArray { id0, id1 });
        editor->showTab (false);
        auto img = editor->createComponentSnapshot (editor->getLocalBounds());
        CHECK (img.getWidth() == 1200);
        editor->showTab (true);
        img = editor->createComponentSnapshot (editor->getLocalBounds());
    }

    // ---- map: geometry + hit testing with a real map file (written the way the worker does)
    {
        juce::Array<var> pts;
        for (int i = 0; i < 24; ++i)
            pts.add (json::object ({ { "bake_id", model.rows()[(size_t) i].id }, { "x", std::cos (i * 0.7) * 0.9 }, { "y", std::sin (i * 0.7) * 0.9 } }));
        auto doc = json::object ({ { "schema", "gnumbat.map/0.1" }, { "map_id", "mp_00000000000000000000" }, { "created_at", json::utcNow() },
                                   { "space", json::object ({ { "embedding_id", "em_00000000000000000000" }, { "feature_set_id", "spectral" }, { "label", "Spectral" } }) },
                                   { "method", json::object ({ { "name", "tsne" }, { "params", json::emptyObject() }, { "seed", 0 } }) },
                                   { "points", var (pts) }, { "quality", json::object ({ { "trustworthiness", 0.9 } }) },
                                   { "disclaimer", "test projection" } });
        json::atomicWriteJson (env.lib.getChildFile ("derived/maps/spectral.json"), doc);
        model.refreshNow();
        pumpMessages (100);                                              // ChangeBroadcaster delivers asynchronously
        CHECK (model.map() != nullptr && model.map()->points.size() == 24);
        auto& mv = editor->mapView();
        editor->showTab (true);
        editor->resized();
        mv.fitView();
        const auto w = juce::Point<float> (0.2f, -0.4f);
        const auto s = mv.worldToScreen (w);
        const auto back = mv.screenToWorld (s);
        CHECK (std::abs (back.x - w.x) < 1e-4f && std::abs (back.y - w.y) < 1e-4f);
        const auto target = model.map()->points[5];
        CHECK (mv.pointAt (mv.worldToScreen ({ target.x, target.y })) == target.bakeId);
        CHECK (mv.pointAt ({ -500.f, -500.f }).isEmpty());
        mv.setColourModeByText ("first tag");
        auto img = editor->createComponentSnapshot (editor->getLocalBounds());
        CHECK (img.getHeight() == 800);
        CHECK (mv.colourMode() == "first tag");
    }

    // ---- BAKE through the real dialog: capture -> notation card -> background write -> library
    {
        editor->showTab (false);
        proc.plan.mode = CapturePlan::Mode::lastBars;  proc.plan.bars = 1.0;
        const auto before = model.rows().size();
        editor->beginBake();
        CHECK (editor->dialogOpen());
        ui::NotationCard* card = nullptr;
        for (auto* c : editor->getChildren()) if ((card = dynamic_cast<ui::NotationCard*> (c)) != nullptr) break;
        CHECK (card != nullptr);
        if (card != nullptr)
        {
            ui::NotationCard::Result r;
            r.accepted = true;
            r.rawNotation = "  Aggressive   metallic rise ";              // verbatim, odd spacing included
            r.profile = notation::freeformProfile();
            r.decompose = true;
            r.decomposer = "testsplit";
            card->onDone (r);
            for (int i = 0; i < 100 && model.rows().size() == before; ++i) pumpMessages (50);
            CHECK (model.rows().size() == before + 1);
            const auto& newest = model.rows().back();
            CHECK (json::getString (newest.view, "notation") == "  Aggressive   metallic rise ");
            CHECK (json::getString (newest.view, "state") == "CAPTURED");
            CHECK (model.selection().size() == 1 && model.selection()[0] == newest.id);
            auto bakeDoc = lib.readBake (newest.id);
            CHECK (json::getString (bakeDoc, "capture/mode") == "last_bars");
            CHECK (std::abs (json::getNumber (bakeDoc, "audio/duration_s") - 2.0) < 1e-3);        // 1 bar at 120 bpm 4/4
            CHECK (json::getNumber (bakeDoc, "capture/timeline/end_sample") == 48000 * 12);
        }
        pumpMessages (300);
        CHECK (! editor->dialogOpen());
    }

    // ---- cancel discards without writing
    {
        const auto before = model.rows().size();
        editor->beginBake();
        ui::NotationCard* card = nullptr;
        for (auto* c : editor->getChildren()) if ((card = dynamic_cast<ui::NotationCard*> (c)) != nullptr) break;
        CHECK (card != nullptr);
        if (card != nullptr) { ui::NotationCard::Result r; r.accepted = false; card->onDone (r); }
        pumpMessages (300);
        CHECK (model.rows().size() == before && ! editor->dialogOpen());
    }

    // ---- EBYS hand-off through the real UI: link -> BAKE (auto) -> file in raw_uploads + Bake says "waiting"
    {
        const auto ebys = env.dir.getChildFile ("EBYS");
        ebys.getChildFile ("src/demucs").createDirectory();
        ebys.getChildFile ("src/demucs/watch_demucs.py").replaceWithText ("# fake\n");
        ebys.getChildFile ("data").createDirectory();
        ebys.getChildFile ("data/current_session.txt").replaceWithText ("ui-session\n");
        CHECK (! editor->handoffActive() && editor->ebysButtonText().startsWith ("LINK"));
        model.settings().setEbysRoot (ebys);
        model.settings().set ("handoff_raw_uploads", true);
        editor->refreshEbys();
        CHECK (editor->handoffActive() && editor->ebysButtonText().contains ("ui-session"));

        editor->showTab (false);
        proc.plan.mode = CapturePlan::Mode::lastBars;  proc.plan.bars = 1.0;
        const auto before = model.rows().size();
        editor->beginBake();
        ui::NotationCard* card = nullptr;
        for (auto* c : editor->getChildren()) if ((card = dynamic_cast<ui::NotationCard*> (c)) != nullptr) break;
        CHECK (card != nullptr);
        if (card != nullptr)
        {
            ui::NotationCard::Result r;
            r.accepted = true;  r.rawNotation = "Heavy Riser";  r.profile = notation::freeformProfile();
            r.decompose = true; r.decomposer = "";                       // "auto"
            card->onDone (r);
            for (int i = 0; i < 100 && model.rows().size() == before; ++i) pumpMessages (50);
            CHECK (model.rows().size() == before + 1);
            const auto id = model.rows().back().id;
            const auto file = ebys.getChildFile ("data/sessions/ui-session/raw_uploads/heavy-riser__" + id + ".wav");
            CHECK (file.existsAsFile());
            model.refreshNow();
            for (int i = 0; i < 40 && json::getString (model.rows().back().view, "handoff") != "waiting"; ++i) { pumpMessages (50); model.refreshNow(); }
            CHECK (json::getString (model.rows().back().view, "handoff") == "waiting");
        }
        pumpMessages (300);

        // unlinked again: BAKE writes nothing into the instrument
        model.settings().setEbysRoot ({});
        editor->refreshEbys();
        CHECK (! editor->handoffActive() && editor->ebysButtonText().startsWith ("LINK"));
        model.settings().set ("handoff_raw_uploads", true);
    }

    // ---- an empty capture is refused with a message, no dialog
    {
        GnumbatProcessor fresh;
        std::unique_ptr<juce::AudioProcessorEditor> e2 (fresh.createEditor());
        auto* ge = dynamic_cast<GnumbatEditor*> (e2.get());
        ge->beginBake();
        CHECK (! ge->dialogOpen());
    }

    // ---- editor state is written back to the processor
    editor->showTab (true);
    model.setSearch ("abc");
    ed.reset();
    CHECK (proc.getUiState ("tab").toString() == "map" && proc.getUiState ("search").toString() == "abc");
}

// ---------------------------------------------------------------------------------------------------- snapshots
static void snapshots (const juce::File& outDir, const juce::File& libRoot)
{
    outDir.createDirectory();
    setEnv ("GNUMBAT_SETTINGS", outDir.getChildFile ("settings.json").getFullPathName());
    setEnv ("GNUMBAT_LIBRARY", libRoot.getFullPathName());

    GnumbatProcessor proc;
    proc.setRateAndBufferSizeDetails (48000.0, 512);
    proc.prepareToPlay (48000.0, 512);
    FakeHost host;
    host.ppqAt0 = 64.0;
    proc.setPlayHead (&host);
    run (proc, &host, 48000 * 4, 48000 * 21, 512);
    proc.plan.mode = CapturePlan::Mode::range;
    proc.plan.in = { 48000 * 8, 64.0 + 16.0, true };
    proc.plan.out = { 48000 * 16, 64.0 + 32.0, true };
    proc.setUiState ("tab", "bank");

    std::unique_ptr<juce::AudioProcessorEditor> ed (proc.createEditor());
    auto* editor = dynamic_cast<GnumbatEditor*> (ed.get());
    editor->setSize (1280, 800);
    pumpMessages (200);
    auto& model = editor->appModel();

    auto save = [&] (const String& name)
    {
        pumpMessages (100);
        auto img = editor->createComponentSnapshot (editor->getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        juce::FileOutputStream out (outDir.getChildFile (name));
        out.setPosition (0); out.truncate();
        png.writeImageToStream (img, out);
        std::cout << "  wrote " << name << " (" << img.getWidth() << "x" << img.getHeight() << ")\n";
    };

    editor->showTab (false);
    if (model.rows().size() > 3)
        model.setSelection ({ model.rows()[3].id }, model.rows()[3].id);
    save ("bank.png");

    model.setChips ({ filter::leaf ("state", "eq", "READY") });
    model.setSearch ("rise");
    model.setSelection ({});
    save ("bank_filtered.png");
    model.setSearch ({});  model.setChips ({});

    editor->showTab (true);
    editor->mapView().setColourModeByText ("first tag");
    if (model.map() != nullptr)
    {
        juce::StringArray sel;
        for (size_t i = 0; i < model.map()->points.size() && sel.size() < 6; i += 3) sel.add (model.map()->points[i].bakeId);
        model.setSelection (sel);
        model.setHover (model.map()->points[7].bakeId);
    }
    save ("map.png");
    model.setHover ({});

    editor->showTab (false);
    editor->beginBake();
    save ("bake_dialog.png");
}

// ---------------------------------------------------------------------------------------------------- interop through the plugin path
static void interopWrite (const juce::File& libRoot)
{
    setEnv ("GNUMBAT_SETTINGS", libRoot.getSiblingFile ("plugin_settings.json").getFullPathName());
    libRoot.deleteRecursively();
    Library::init (libRoot);
    Library lib (libRoot);

    GnumbatProcessor proc;
    FakeHost host;
    proc.setPlayHead (&host);
    proc.setRateAndBufferSizeDetails (48000.0, 512);
    proc.prepareToPlay (48000.0, 512);
    run (proc, &host, 0, 48000 * 20, 512);

    const char* notes[] = { "  rise / tension  ", "", "kick-128 BPM-4 bars" };
    for (int i = 0; i < 3; ++i)
    {
        proc.plan.mode = CapturePlan::Mode::range;
        proc.plan.in = { 48000 * (2 + 4 * i), 4.0 + 8.0 * i, true };
        proc.plan.out = { 48000 * (2 + 4 * i) + 48000 * 3, 4.0 + 8.0 * i + 6.0, true };
        auto pc = proc.prepareCapture (proc.plan);
        CHECK_MSG (pc.ok, pc.problem);
        auto nb = std::move (pc.bake);
        nb.rawNotation = notes[i];
        nb.profile = i == 2 ? notation::builtinProfile ("np_musical_dash") : notation::freeformProfile();
        nb.decomposer = "testsplit";
        nb.processParams = json::object ({ { "auto_map", i != 2 } });
        String id;
        auto r = lib.createBake (nb, id);
        CHECK_MSG (r.wasOk(), r.getErrorMessage());
    }
    std::cout << "  plugin path wrote " << lib.listBakeIds().size() << " Bakes\n";
}

static void interopVerify (const juce::File& libRoot)
{
    Library lib (libRoot);
    const auto ids_ = lib.listBakeIds();
    CHECK (ids_.size() == 3);
    const char* notes[] = { "  rise / tension  ", "", "kick-128 BPM-4 bars" };
    for (int i = 0; i < ids_.size(); ++i)
    {
        const auto st = lib.readState (ids_[i]);
        CHECK_MSG (json::getString (st, "state") == "READY", ids_[i] + " " + json::getString (st, "state") + " " + juce::JSON::toString (st.getProperty ("error", {}), true));
        CHECK (json::getString (lib.readSemantic (ids_[i]), "raw_notation") == String (notes[i]));         // verbatim through capture -> Python worker -> back
        const auto bake = lib.readBake (ids_[i]);
        CHECK (json::getNumber (bake, "capture/timeline/start_sample") == 48000 * (2 + 4 * i));
        CHECK (json::getBool (bake, "capture/complete"));
        CHECK (json::getNumber (bake, "capture/tempo_bpm") == 120.0);
        CHECK (std::abs (json::getNumber (bake, "audio/duration_s") - 3.0) < 1e-6);
        CHECK (lib.readAnalysis (ids_[i]).getDynamicObject() != nullptr);
        CHECK (lib.stemFiles (ids_[i]).size() == 4);
    }
    auto sem = lib.readSemantic (ids_[2]);
    CHECK (json::getNumber (sem, "fields/tempo") == 128 && json::getNumber (sem, "fields/duration_bars") == 4);
    CHECK (json::getStrings (lib.readSemantic (ids_[1]), "tags").isEmpty());
    std::cout << "  plugin-path Bakes verified after the Python worker\n";
}

int main (int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI gui;
    juce::File snapDir, snapLib, iw, iv;
    for (int i = 1; i < argc; ++i)
    {
        const String a (argv[i]);
        if (a == "--snapshot" && i + 2 < argc) { snapDir = juce::File (argv[i + 1]); snapLib = juce::File (argv[i + 2]); i += 2; }
        else if (a == "--interop-write" && i + 1 < argc) iw = juce::File (argv[++i]);
        else if (a == "--interop-verify" && i + 1 < argc) iv = juce::File (argv[++i]);
    }
    if (snapDir != juce::File()) snapshots (snapDir, snapLib);
    else if (iw != juce::File()) interopWrite (iw);
    else if (iv != juce::File()) interopVerify (iv);
    else
    {
        std::cout << "processor\n"; testProcessor();
        std::cout << "ui\n";        testUi();
    }
    std::cout << (g_fail == 0 ? "plugin: all tests passed" : "plugin: FAILURES") << "  (" << g_checks << " checks, " << g_fail << " failed)\n";
    return g_fail == 0 ? 0 : 1;
}
