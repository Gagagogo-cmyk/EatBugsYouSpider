#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "../core/Ids.h"
#include "../core/JsonIo.h"
#include "../core/Settings.h"
#include <cmath>

#ifndef GNUMBAT_VERSION
 #define GNUMBAT_VERSION "0.1.0"
#endif

namespace gnumbat
{
    GnumbatProcessor::GnumbatProcessor()
        : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                           .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
          sessionId (ids::ulid())
    {
        ringSeconds = Settings::load().ringSeconds();
    }

    bool GnumbatProcessor::isBusesLayoutSupported (const BusesLayout& l) const
    {
        // A transparent tap: output layout == input layout, mono or stereo.
        const auto in = l.getMainInputChannelSet(), out = l.getMainOutputChannelSet();
        return in == out && (in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo());
    }

    void GnumbatProcessor::prepareToPlay (double sampleRate, int)
    {
        const int nch = juce::jlimit (1, kMaxCaptureChannels, getTotalNumInputChannels());
        // Hosts call prepareToPlay on every transport start; only rebuild (= discard captured audio) when something changed.
        if (! capture.isPrepared() || std::abs (preparedRate - sampleRate) > 0.5 || preparedChannels != nch || std::abs (preparedRing - ringSeconds) > 0.5)
        {
            capture.prepare (sampleRate, nch, ringSeconds);
            preparedRate = sampleRate;  preparedChannels = nch;  preparedRing = ringSeconds;
            ownTimeline = 0;
        }
        tSampleRate.store (sampleRate, std::memory_order_relaxed);
    }

    void GnumbatProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
    {
        juce::ScopedNoDenormals noDenormals;
        const int n = buffer.getNumSamples();
        const int inCh = juce::jmin (getTotalNumInputChannels(), buffer.getNumChannels());

        // ---- host transport (RT-safe reads of the play head; nothing allocates)
        bool playing = false, recording = false, looping = false, hasLoop = false, hasPpq = false, hostTimeline = false;
        juce::int64 timeSamples = -1;
        double ppq = 0.0, bpm = 0.0, loopStart = 0.0, loopEnd = 0.0;
        int num = 0, den = 0;

        if (auto* ph = getPlayHead())
            if (auto pos = ph->getPosition())
            {
                playing = pos->getIsPlaying();
                recording = pos->getIsRecording();
                looping = pos->getIsLooping();
                if (auto t = pos->getTimeInSamples()) { timeSamples = *t; hostTimeline = true; }
                if (auto p = pos->getPpqPosition()) { ppq = *p; hasPpq = true; }
                if (auto b = pos->getBpm()) bpm = *b;
                if (auto ts = pos->getTimeSignature()) { num = ts->numerator; den = ts->denominator; }
                if (auto lp = pos->getLoopPoints()) { loopStart = lp->ppqStart; loopEnd = lp->ppqEnd; hasLoop = lp->ppqEnd > lp->ppqStart; }
            }

        // Timeline addressing: with a host timeline only PLAYING blocks are addressable (a stopped transport
        // repeats the same position). Without one, the plugin counts its own samples so range capture still works.
        juce::int64 tl = -1;
        if (hostTimeline) tl = playing ? timeSamples : -1;
        else { tl = ownTimeline; timeSamples = ownTimeline; }
        ownTimeline += n;

        if (inCh > 0)
            capture.push (buffer.getArrayOfReadPointers(), inCh, n, tl);

        // ---- pass-through (in place): nothing to do for shared channels; silence any extra outputs
        for (int c = getTotalNumInputChannels(); c < getTotalNumOutputChannels(); ++c)
            buffer.clear (c, 0, n);

        // ---- meters (decaying peak)
        for (int c = 0; c < juce::jmin (2, inCh); ++c)
        {
            const float pk = buffer.getMagnitude (c, 0, n);
            const float prev = level[c].load (std::memory_order_relaxed);
            level[c].store (pk > prev ? pk : prev * std::pow (0.5f, (float) n / (float) juce::jmax (1.0, getSampleRate() * 0.25)), std::memory_order_relaxed);
        }

        // ---- mailbox to the UI
        tHostTimeline.store (hostTimeline, std::memory_order_relaxed);
        tPlaying.store (hostTimeline ? playing : true, std::memory_order_relaxed);
        tRecording.store (recording, std::memory_order_relaxed);
        tLooping.store (looping, std::memory_order_relaxed);
        tOffline.store (isNonRealtime(), std::memory_order_relaxed);
        tHasLoop.store (hasLoop, std::memory_order_relaxed);
        tHasPpq.store (hasPpq, std::memory_order_relaxed);
        // "now" = the END of this block: a marker set from it points at audio that has already been captured
        const double sr = juce::jmax (1.0, getSampleRate());
        tSamples.store (hostTimeline ? timeSamples + (playing ? n : 0) : ownTimeline, std::memory_order_relaxed);
        tPpq.store (playing && bpm > 0.0 ? ppq + (double) n / sr * bpm / 60.0 : ppq, std::memory_order_relaxed);
        tBpm.store (bpm, std::memory_order_relaxed);
        tNum.store (num, std::memory_order_relaxed);
        tDen.store (den, std::memory_order_relaxed);
        tLoopStart.store (loopStart, std::memory_order_relaxed);
        tLoopEnd.store (loopEnd, std::memory_order_relaxed);
        tValid.store (true, std::memory_order_release);
    }

    // ---------------------------------------------------------------------------------------- UI-facing
    TransportSnapshot GnumbatProcessor::transport() const
    {
        TransportSnapshot t;
        t.valid = tValid.load (std::memory_order_acquire);
        t.hostTimeline = tHostTimeline.load (std::memory_order_relaxed);
        t.playing = tPlaying.load (std::memory_order_relaxed);
        t.recording = tRecording.load (std::memory_order_relaxed);
        t.looping = tLooping.load (std::memory_order_relaxed);
        t.offline = tOffline.load (std::memory_order_relaxed);
        t.hasLoop = tHasLoop.load (std::memory_order_relaxed);
        t.samples = tSamples.load (std::memory_order_relaxed);
        t.hasPpq = tHasPpq.load (std::memory_order_relaxed);
        t.ppq = tPpq.load (std::memory_order_relaxed);
        t.bpm = tBpm.load (std::memory_order_relaxed);
        t.tsNum = tNum.load (std::memory_order_relaxed);
        t.tsDen = tDen.load (std::memory_order_relaxed);
        t.loopStartPpq = tLoopStart.load (std::memory_order_relaxed);
        t.loopEndPpq = tLoopEnd.load (std::memory_order_relaxed);
        t.sampleRate = capture.isPrepared() ? capture.sampleRate() : tSampleRate.load (std::memory_order_relaxed);
        t.written = capture.totalWritten();
        t.level[0] = level[0].load (std::memory_order_relaxed);
        t.level[1] = level[1].load (std::memory_order_relaxed);
        return t;
    }

    juce::String GnumbatProcessor::hostName() const
    {
        if (isStandalone()) return "Standalone";
        const juce::String d (juce::PluginHostType().getHostDescription());
        return d.isEmpty() || d == "Unknown" ? juce::String ("Unknown host") : d;
    }

    juce::String GnumbatProcessor::trackName() const { const juce::ScopedLock sl (metaLock); return track; }

    void GnumbatProcessor::updateTrackProperties (const TrackProperties& p)
    {
        const juce::ScopedLock sl (metaLock);
        track = p.name.value_or (juce::String());
    }

    Marker GnumbatProcessor::markerNow() const
    {
        const auto t = transport();
        Marker m;
        if (! t.valid || t.samples < 0) return m;
        m.sample = t.samples; m.ppq = t.ppq; m.hasPpq = t.hasPpq;
        return m;
    }

    juce::int64 GnumbatProcessor::samplesForBeats (double beats) const
    {
        const auto t = transport();
        const double bpm = t.bpm > 0.0 ? t.bpm : 120.0;
        return (juce::int64) std::llround (beats * 60.0 / bpm * juce::jmax (1.0, t.sampleRate));
    }

    bool GnumbatProcessor::loopMarkers (Marker& a, Marker& b) const
    {
        const auto t = transport();
        if (! t.valid || ! t.hasLoop || ! t.hasPpq || t.samples < 0 || t.bpm <= 0.0) return false;
        // Anchor on the current transport position and walk to the loop points at the current tempo.
        const double sPerBeat = 60.0 / t.bpm * t.sampleRate;
        a.sample = t.samples + (juce::int64) std::llround ((t.loopStartPpq - t.ppq) * sPerBeat);
        b.sample = t.samples + (juce::int64) std::llround ((t.loopEndPpq - t.ppq) * sPerBeat);
        a.ppq = t.loopStartPpq; b.ppq = t.loopEndPpq; a.hasPpq = b.hasPpq = true;
        return a.sample >= 0 && b.sample > a.sample;
    }

    double GnumbatProcessor::coverageOf (const Marker& in, const Marker& out) const
    {
        if (! in.isSet() || ! out.isSet() || out.sample <= in.sample || ! capture.isPrepared()) return 0.0;
        juce::int64 covered = 0;
        for (auto& iv : capture.coverage (in.sample, out.sample)) covered += iv.length();
        return (double) covered / (double) (out.sample - in.sample);
    }

    PreparedCapture GnumbatProcessor::prepareCapture (const CapturePlan& p) const
    {
        PreparedCapture pc;
        if (! capture.isPrepared() || ! transport().valid)
        {
            pc.problem = "Nothing has flowed through the plugin yet. Press play in the host (or feed the standalone input).";
            return pc;
        }
        const auto t = transport();
        const double sr = capture.sampleRate();
        CaptureBuffer::Snapshot snap;
        Marker from, to;
        double wantSamples = 0.0;
        bool timelineKnown = false;

        switch (p.mode)
        {
            case CapturePlan::Mode::range:
            case CapturePlan::Mode::loop:
            {
                from = p.in; to = p.out;
                if (p.mode == CapturePlan::Mode::loop && ! loopMarkers (from, to)) { pc.problem = "The host is not reporting loop points."; return pc; }
                if (! from.isSet() || ! to.isSet() || to.sample <= from.sample) { pc.problem = "Set IN and OUT first (IN must be before OUT)."; return pc; }
                snap = capture.readRange (from.sample, to.sample);
                wantSamples = (double) (to.sample - from.sample);
                timelineKnown = true;
                break;
            }
            case CapturePlan::Mode::lastBars:
            case CapturePlan::Mode::lastSeconds:
            {
                double secs = p.seconds;
                if (p.mode == CapturePlan::Mode::lastBars)
                {
                    const double bpm = t.bpm > 0.0 ? t.bpm : 120.0;
                    const double beatsPerBar = (t.tsNum > 0 && t.tsDen > 0) ? t.tsNum * 4.0 / t.tsDen : 4.0;
                    secs = p.bars * beatsPerBar * 60.0 / bpm;
                }
                wantSamples = std::round (secs * sr);
                snap = capture.readLast ((juce::int64) wantSamples);
                if (snap.timelineStart >= 0) { from.sample = snap.timelineStart; to.sample = snap.timelineStart + (juce::int64) snap.channels[0].size(); timelineKnown = true; }
                break;
            }
        }

        if (snap.overrun) { pc.problem = "The capture ring was overwritten while copying (range too old for the ring, or the buffer is very short). Try a shorter or more recent range."; return pc; }
        if (snap.channels.empty() || snap.channels[0].empty() || snap.coveredSamples <= 0)
        {
            pc.problem = p.mode == CapturePlan::Mode::range || p.mode == CapturePlan::Mode::loop
                       ? "None of that range has passed through the plugin. Play it in the host once (capture is by playing through)."
                       : "Nothing captured yet.";
            return pc;
        }

        pc.coverage = juce::jlimit (0.0, 1.0, (double) snap.coveredSamples / wantSamples);
        pc.bake.audio.channels = std::move (snap.channels);
        pc.bake.audio.sampleRate = sr;
        pc.seconds = (double) pc.bake.audio.frames() / sr;

        auto& m = pc.bake.capture;
        m.hostName = hostName();
        m.pluginVersion = GNUMBAT_VERSION;
        m.session = sessionId;
        m.trackName = trackName();
        m.tempoBpm = t.bpm;
        m.timeSigNum = t.tsNum; m.timeSigDen = t.tsDen;
        m.coverage = pc.coverage;
        m.complete = pc.coverage >= 0.999;
        m.offline = t.offline;
        m.mode = CapturePlan::modeName (p.mode);
        if (timelineKnown && t.hostTimeline)
        {
            m.hasTimeline = true;
            m.startSample = from.sample; m.endSample = to.sample; m.timelineSampleRate = sr;
            if (from.hasPpq && to.hasPpq) { m.hasPpq = true; m.startPpq = from.ppq; m.endPpq = to.ppq; }
        }
        pc.bake.isImport = false;
        pc.ok = true;
        pc.summary = juce::String (pc.seconds, 2) + " s  ·  " + juce::String (juce::roundToInt (pc.coverage * 100.0)) + " % heard";
        return pc;
    }

    // ---------------------------------------------------------------------------------------- state
    juce::var GnumbatProcessor::uiState() const { const juce::ScopedLock sl (metaLock); return ui.clone(); }
    void GnumbatProcessor::setUiState (const juce::String& key, const juce::var& v) { const juce::ScopedLock sl (metaLock); ui.getDynamicObject()->setProperty (key, v); }
    juce::var GnumbatProcessor::getUiState (const juce::String& key, const juce::var& fb) const { const juce::ScopedLock sl (metaLock); return ui.hasProperty (key) ? ui.getProperty (key, fb) : fb; }

    static juce::var markerVar (const Marker& m)
    {
        return m.isSet() ? json::object ({ { "sample", (juce::int64) m.sample }, { "ppq", m.ppq }, { "has_ppq", m.hasPpq } }) : juce::var();
    }
    static Marker markerFrom (const juce::var& v)
    {
        Marker m;
        if (v.getDynamicObject() == nullptr) return m;
        m.sample = (juce::int64) json::getNumber (v, "sample", -1);
        m.ppq = json::getNumber (v, "ppq");
        m.hasPpq = json::getBool (v, "has_ppq");
        return m;
    }

    void GnumbatProcessor::getStateInformation (juce::MemoryBlock& dest)
    {
        // Only markers and UI preferences are session state. Audio and Bakes live in the library, never in the project file.
        auto planVar = json::object ({ { "mode", CapturePlan::modeName (plan.mode) }, { "in", markerVar (plan.in) }, { "out", markerVar (plan.out) },
                                       { "bars", plan.bars }, { "seconds", plan.seconds } });
        auto doc = json::object ({ { "schema", "gnumbat.plugin_state/0.1" }, { "plan", planVar }, { "ui", uiState() } });
        const auto text = json::toText (doc, false);
        dest.append (text.toRawUTF8(), std::strlen (text.toRawUTF8()));
    }

    void GnumbatProcessor::setStateInformation (const void* data, int size)
    {
        juce::var doc;
        if (size <= 0 || ! juce::JSON::parse (juce::String::fromUTF8 (static_cast<const char*> (data), size), doc).wasOk()) return;
        if (! json::getString (doc, "schema").startsWith ("gnumbat.plugin_state/")) return;
        const auto pv = json::get (doc, "plan");
        const auto mode = json::getString (pv, "mode", "last_bars");
        plan.mode = mode == "range" ? CapturePlan::Mode::range : mode == "loop" ? CapturePlan::Mode::loop
                  : mode == "last_seconds" ? CapturePlan::Mode::lastSeconds : CapturePlan::Mode::lastBars;
        plan.in = markerFrom (json::get (pv, "in"));
        plan.out = markerFrom (json::get (pv, "out"));
        plan.bars = juce::jlimit (0.25, 512.0, json::getNumber (pv, "bars", 4.0));
        plan.seconds = juce::jlimit (0.1, 900.0, json::getNumber (pv, "seconds", 10.0));
        if (auto* o = json::get (doc, "ui").getDynamicObject())
        {
            const juce::ScopedLock sl (metaLock);
            ui = json::get (doc, "ui").clone();
            (void) o;
        }
    }

    juce::AudioProcessorEditor* GnumbatProcessor::createEditor() { return new GnumbatEditor (*this); }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new gnumbat::GnumbatProcessor(); }
