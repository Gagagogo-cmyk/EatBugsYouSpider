# Included from ../CMakeLists.txt when GNUMBAT_BUILD_PLUGIN is ON.
juce_add_plugin(GnumbatPlugin
    COMPANY_NAME "Gnumbat"
    PLUGIN_MANUFACTURER_CODE Gnmb
    PLUGIN_CODE Gnbt
    FORMATS VST3 Standalone
    PRODUCT_NAME "Gnumbat"
    BUNDLE_ID org.gnumbat.plugin
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    VST3_CATEGORIES "Fx" "Analyzer"
    COPY_PLUGIN_AFTER_BUILD FALSE)

target_sources(GnumbatPlugin PRIVATE ${GNUMBAT_PLUGIN_SOURCES})

target_compile_definitions(GnumbatPlugin PUBLIC
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
    GNUMBAT_VERSION="${PROJECT_VERSION}")

target_link_libraries(GnumbatPlugin
    PRIVATE juce::juce_audio_utils juce::juce_cryptography
    PUBLIC juce::juce_recommended_config_flags juce::juce_recommended_warning_flags)
