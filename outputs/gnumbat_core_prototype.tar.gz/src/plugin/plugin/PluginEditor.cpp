#include "PluginEditor.h"
#include "../core/Handoff.h"
#include "ui/NotationCard.h"
#include "../core/Jobs.h"
#include "../core/Ids.h"
#include "../core/JsonIo.h"

namespace gnumbat
{
    using juce::String;
    using juce::var;

    GnumbatEditor::GnumbatEditor (GnumbatProcessor& p)
        : AudioProcessorEditor (&p), proc (p), capture (p, *this), bankPane (model, *this), mapPane (model, *this), inspector (model, *this)
    {
        setLookAndFeel (&laf);
        setOpaque (true);

        addAndMakeVisible (capture);
        addAndMakeVisible (bankPane);
        addChildComponent (mapPane);
        addAndMakeVisible (inspector);

        libraryButton.setTooltip ("Click to open or create a library folder. A library is just a folder of Bakes: copy it, back it up, or open it on another machine.");
        libraryButton.onClick = [this] { chooseLibrary(); };
        addAndMakeVisible (libraryButton);
        ebysButton.onClick = [this]
        {
            if (model.settings().ebysRoot() == juce::File()) { chooseEbys(); return; }
            juce::PopupMenu m;
            m.addItem (1, "change EBYS folder...");
            m.addItem (2, "send every Bake to the instrument's raw_uploads/", true, model.settings().handoffEnabled());
            m.addItem (3, "unlink EBYS");
            m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&ebysButton), [this] (int r)
            {
                if (r == 1) chooseEbys();
                else if (r == 2) { model.settings().set ("handoff_raw_uploads", ! model.settings().handoffEnabled()); model.settings().save(); refreshEbys(); }
                else if (r == 3) { model.settings().setEbysRoot ({}); model.settings().save(); refreshEbys(); notify ("EBYS unlinked: Bakes stay in the Gnumbat library only"); }
            });
        };
        addAndMakeVisible (ebysButton);
        refreshEbys();
        for (auto* b : { &bankTab, &mapTab }) { b->setClickingTogglesState (false); addAndMakeVisible (*b); }
        bankTab.onClick = [this] { showTab (false); };
        mapTab.onClick = [this] { showTab (true); };
        workerButton.setTooltip ("Start the background worker (stems + analysis + map). It keeps running after the DAW closes; work queued meanwhile waits safely.");
        workerButton.onClick = [this] { model.ensureWorker(); notify ("starting worker ..."); };
        addAndMakeVisible (workerButton);

        capture.onBake = [this] { beginBake(); };
        capture.onImport = [this]
        {
            chooser = std::make_unique<juce::FileChooser> ("Import audio as Bakes", juce::File(), "*.wav;*.aif;*.aiff;*.flac;*.mp3;*.ogg");
            chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectMultipleItems | juce::FileBrowserComponent::canSelectFiles,
                                  [this] (const juce::FileChooser& fc) { beginImport (fc.getResults()); });
        };

        if (auto r = model.openLibrary (model.settings().libraryRoot()); r.failed())
            notify (r.getErrorMessage(), true);
        restoreUi();
        model.addChangeListener (this);
        changeListenerCallback (nullptr);

        setResizable (true, true);
        setResizeLimits (940, 620, 2600, 1800);
        setSize (1200, 800);
        startTimerHz (2);
    }

    GnumbatEditor::~GnumbatEditor()
    {
        stopTimer();
        model.removeChangeListener (this);
        saveUi();
        dialog.reset();
        setLookAndFeel (nullptr);
    }

    // ---------------------------------------------------------------------------------------------------------- state
    void GnumbatEditor::restoreUi()
    {
        mapShown = proc.getUiState ("tab", "bank").toString() == "map";
        model.setSearch (proc.getUiState ("search", "").toString());
        if (auto* chips = proc.getUiState ("chips", {}).getArray()) { juce::Array<var> c = *chips; model.setChips (c); }
        model.setSort (proc.getUiState ("sort", "created").toString(), (bool) proc.getUiState ("sort_asc", false));
        if (auto sp = proc.getUiState ("map_space", "spectral").toString(); sp.isNotEmpty()) model.setMapSpace (sp);
        const auto cm = proc.getUiState ("colour_by", "").toString();
        if (cm.isNotEmpty()) mapPane.setColourModeByText (cm);
        lastProfileId = proc.getUiState ("profile", "np_freeform").toString();
        capture.refreshFromPlan();
        showTab (mapShown);
    }

    void GnumbatEditor::saveUi()
    {
        proc.setUiState ("tab", mapShown ? "map" : "bank");
        proc.setUiState ("search", model.search());
        proc.setUiState ("chips", var (model.chips()));
        proc.setUiState ("sort", model.sortKey());
        proc.setUiState ("sort_asc", model.sortAscending());
        proc.setUiState ("map_space", model.mapSpace());
        proc.setUiState ("colour_by", mapPane.colourMode());
        proc.setUiState ("profile", lastProfileId);
    }

    void GnumbatEditor::showTab (bool map)
    {
        mapShown = map;
        bankPane.setVisible (! map);
        mapPane.setVisible (map);
        bankTab.setToggleState (! map, juce::dontSendNotification);
        mapTab.setToggleState (map, juce::dontSendNotification);
        if (isShowing()) { if (map) mapPane.grabKeyboardFocus(); else bankPane.grabKeyboardFocus(); }   // not showable yet during construction
        repaint();
    }

    void GnumbatEditor::changeListenerCallback (juce::ChangeBroadcaster*)
    {
        const auto path = model.root().getFullPathName();
        const auto home = juce::File::getSpecialLocation (juce::File::userHomeDirectory).getFullPathName();
        libraryButton.setButtonText (model.hasLibrary() ? (path.startsWith (home) ? "~" + path.substring (home.length()) : path) : String ("(no library - click to choose)"));
        if (model.lastMessage.isNotEmpty()) { notify (model.lastMessage, false); model.lastMessage = {}; }
        repaint (headerRect);
    }

    void GnumbatEditor::timerCallback()
    {
        if (statusUntil != 0 && juce::Time::currentTimeMillis() > statusUntil) { status = {}; statusUntil = 0; repaint (tabsRect); }
        const bool alive = model.snapshot().worker.alive;
        workerButton.setVisible (! alive && model.hasLibrary());
        if (juce::Time::currentTimeMillis() - lastEbysCheck > 3000) refreshEbys();      // the instrument's session can change under us
        repaint (headerRect);
    }

    void GnumbatEditor::notify (const String& msg, bool isError)
    {
        status = msg.replaceCharacter ('\n', ' ');
        statusIsError = isError;
        statusUntil = juce::Time::currentTimeMillis() + (isError ? 12000 : 6000);
        repaint (tabsRect);
    }

    // ---------------------------------------------------------------------------------------------------------- layout
    void GnumbatEditor::paint (juce::Graphics& g)
    {
        g.fillAll (ui::col::bg);
        // header
        g.setColour (ui::col::panelHi); g.fillRect (headerRect);
        g.setColour (ui::col::line);    g.drawHorizontalLine (headerRect.getBottom() - 1, 0.0f, (float) getWidth());
        g.setColour (ui::col::green);   g.setFont (ui::mono (15.0f, true));
        g.drawText ("GNUMBAT", headerRect.getX() + 12, headerRect.getY(), 92, headerRect.getHeight(), juce::Justification::centredLeft);
        g.setColour (ui::col::dim);     g.setFont (ui::mono (10.5f));
        g.drawText ("library", libraryButton.getX() - 46, headerRect.getY(), 44, headerRect.getHeight(), juce::Justification::centredRight);

        const auto& snap = model.snapshot();
        const auto& w = snap.worker;
        const bool busy = w.alive && w.currentJobType.isNotEmpty();
        g.setColour (! w.alive ? ui::col::red : busy ? ui::col::amber : ui::col::green);
        g.fillEllipse ((float) ledRect.getX(), (float) ledRect.getCentreY() - 4.0f, 8.0f, 8.0f);
        g.setColour (ui::col::text); g.setFont (ui::mono (11.5f));
        String ws = w.summary();
        const auto& j = snap.jobs;
        ws << "   queue " << j.pending << " · running " << j.running;
        g.drawText (ws, ledRect.withTrimmedLeft (14), juce::Justification::centredLeft, true);
        if (j.failed > 0)
        {
            g.setColour (ui::col::red);
            g.drawText (String (j.failed) + " failed", ledRect.withTrimmedLeft (14), juce::Justification::centredRight, true);
        }

        // status line in the tab row
        if (status.isNotEmpty())
        {
            g.setColour (statusIsError ? ui::col::red : ui::col::amber);
            g.setFont (ui::mono (11.5f));
            g.drawText (status, tabsRect.withTrimmedLeft (170), juce::Justification::centredRight, true);
        }
    }

    void GnumbatEditor::resized()
    {
        auto r = getLocalBounds();
        headerRect = r.removeFromTop (30);
        {
            auto h = headerRect.reduced (6, 4);
            h.removeFromLeft (104 + 46);
            const int ledW = juce::jmin (h.getWidth() / 2, 420);
            auto right = h.removeFromRight (ledW);
            if (workerButton.isVisible() || true)
            {
                workerButton.setBounds (right.removeFromRight (112));
                right.removeFromRight (6);
            }
            ledRect = right;
            libraryButton.setBounds (h.removeFromLeft (juce::jmin (h.getWidth() - 8, 460)));
            h.removeFromLeft (8);
            ebysButton.setBounds (h.removeFromLeft (juce::jmin (h.getWidth(), 176)));
        }
        capture.setBounds (r.removeFromTop (92));
        tabsRect = r.removeFromTop (30);
        {
            auto t = tabsRect.reduced (6, 3);
            bankTab.setBounds (t.removeFromLeft (76)); t.removeFromLeft (2);
            mapTab.setBounds (t.removeFromLeft (76));
        }
        const int inspW = juce::jlimit (300, 420, r.getWidth() / 3);
        inspector.setBounds (r.removeFromRight (inspW));
        r.removeFromRight (1);
        bankPane.setBounds (r.reduced (6, 2));
        mapPane.setBounds (r.reduced (6, 2));
        if (dialog) dialog->setBounds (getLocalBounds());
    }

    bool GnumbatEditor::keyPressed (const juce::KeyPress& k)
    {
        if (k == juce::KeyPress::tabKey) { showTab (! mapShown); return true; }
        return false;
    }

    // ---------------------------------------------------------------------------------------------------------- dialogs
    void GnumbatEditor::showDialog (std::unique_ptr<juce::Component> d)
    {
        dialog = std::move (d);
        addAndMakeVisible (*dialog);
        dialog->setBounds (getLocalBounds());
        dialog->toFront (true);
    }

    void GnumbatEditor::closeDialogSoon()
    {
        juce::MessageManager::callAsync ([safe = juce::Component::SafePointer<GnumbatEditor> (this)]
        {
            if (safe != nullptr) { safe->dialog.reset(); safe->repaint(); }
        });
    }

    void GnumbatEditor::prompt (const String& title, const String& message, const juce::Array<ui::PromptField>& fields, const String& okText, std::function<void (juce::StringArray)> onOk)
    {
        auto card = std::make_unique<ui::DialogCard> (title, message);
        for (auto& f : fields) card->addField (f);
        card->addButton ("CANCEL");
        card->addButton (okText, true);
        auto* raw = card.get();
        card->onResult = [this, onOk] (int b, const juce::StringArray& v, const juce::Array<bool>&)
        {
            closeDialogSoon();
            if (b == 1 && onOk) onOk (v);
        };
        showDialog (std::move (card));
        raw->focusFirst();
    }

    void GnumbatEditor::confirm (const String& title, const String& message, const String& okText, std::function<void()> onYes, bool danger)
    {
        auto card = std::make_unique<ui::DialogCard> (title, message);
        card->addButton ("CANCEL");
        card->addButton (okText, true, danger);
        card->onResult = [this, onYes] (int b, const juce::StringArray&, const juce::Array<bool>&)
        {
            closeDialogSoon();
            if (b == 1 && onYes) onYes();
        };
        showDialog (std::move (card));
        if (dialog->isShowing()) dialog->grabKeyboardFocus();
    }

    // ---------------------------------------------------------------------------------------------------------- library chooser
    void GnumbatEditor::chooseLibrary()
    {
        chooser = std::make_unique<juce::FileChooser> ("Choose (or create) a Gnumbat library folder", model.hasLibrary() ? model.root() : Settings::defaultLibraryRoot(), "");
        chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories, [this] (const juce::FileChooser& fc)
        {
            const auto dir = fc.getResult();
            if (dir == juce::File()) return;
            if (auto r = model.openLibrary (dir); r.failed()) { notify (r.getErrorMessage(), true); return; }
            model.settings().save();
            notify ("library: " + dir.getFullPathName());
        });
    }

    // ---------------------------------------------------------------------------------------------------------- EBYS hand-off
    bool GnumbatEditor::handoffActive() const { return ebysOk && model.settings().handoffEnabled(); }
    juce::String GnumbatEditor::autoLabel() const { return handoffActive() ? String ("auto (EBYS instrument)") : String ("auto"); }

    void GnumbatEditor::refreshEbys()
    {
        lastEbysCheck = juce::Time::currentTimeMillis();
        const auto root = model.settings().ebysRoot();
        ebysOk = false;
        ebysSession = {};
        String text = "LINK EBYS ...";
        String tip = "Every Bake's audio can also be written into your EBYS instrument's raw_uploads/, so its own Demucs + FluCoMa pipeline processes it. Click to choose the EBYS repo folder.";
        if (root != juce::File())
        {
            handoff::Target t;
            if (auto r = handoff::resolve (root, t, false); r.wasOk())
            {
                ebysOk = true;
                ebysSession = t.sessionId;
                text = (model.settings().handoffEnabled() ? "-> EBYS: " : "EBYS (off): ") + t.sessionId;
                tip = "Bakes are also written to " + t.rawUploads.getFullPathName() + " (the instrument's active session). Click for options.";
            }
            else { text = "EBYS ?"; tip = r.getErrorMessage(); }
        }
        if (ebysButton.getButtonText() != text) ebysButton.setButtonText (text);
        ebysButton.setTooltip (tip);
    }

    void GnumbatEditor::chooseEbys()
    {
        chooser = std::make_unique<juce::FileChooser> ("Choose your EBYS repo folder (the one containing src/ and data/)", model.settings().ebysRoot(), "");
        chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories, [this] (const juce::FileChooser& fc)
        {
            const auto dir = fc.getResult();
            if (dir == juce::File()) return;
            handoff::Target t;
            if (auto r = handoff::resolve (dir, t, false); r.failed()) { notify (r.getErrorMessage(), true); return; }
            model.settings().setEbysRoot (dir);
            model.settings().set ("handoff_raw_uploads", true);
            model.settings().save();
            refreshEbys();
            notify ("EBYS linked: new Bakes are also written to " + t.rawUploads.getFullPathName());
        });
    }

    // ---------------------------------------------------------------------------------------------------------- bake
    juce::StringArray GnumbatEditor::decomposerChoices() const
    {
        auto d = model.snapshot().worker.decomposers;
        if (! model.snapshot().worker.alive) d = { "demucs", "testsplit" };     // worker not running yet: show what it usually offers
        return d;
    }

    void GnumbatEditor::beginBake()
    {
        if (dialog != nullptr) return;
        if (! model.hasLibrary()) { notify ("Choose a library folder first (top bar).", true); return; }

        // 1. Copy the audio out of the ring NOW: the ring keeps overwriting itself while the user types.
        auto pc = proc.prepareCapture (proc.plan);
        if (! pc.ok) { notify (pc.problem, true); return; }

        String detail = pc.summary + "   ·   " + proc.hostName();
        if (handoffActive()) detail << "   ·   -> EBYS raw_uploads (" + ebysSession + ")";
        if (proc.plan.mode == CapturePlan::Mode::range)
            detail << "   ·   " << ui::CapturePanel::formatMarker (proc.plan.in, proc.transport()) << " -> " << ui::CapturePanel::formatMarker (proc.plan.out, proc.transport());
        String warning;
        if (pc.coverage < 0.999)
            warning = "Only " + String (juce::roundToInt (pc.coverage * 100.0)) + " % of the requested span has been heard - the rest would be silence. The Bake will be marked partial.";

        auto profiles = model.lib().listProfiles();
        auto card = std::make_unique<ui::NotationCard> ("Notate this Bake", detail, "", profiles, lastProfileId, decomposerChoices(), true, warning, autoLabel());
        auto shared = std::make_shared<NewBake> (std::move (pc.bake));
        card->onDone = [this, shared] (ui::NotationCard::Result r)
        {
            closeDialogSoon();
            if (! r.accepted) { notify ("capture discarded"); return; }
            lastProfileId = json::getString (r.profile, "profile_id", "np_freeform");
            auto nb = std::move (*shared);
            nb.rawNotation = r.rawNotation;
            nb.profile = r.profile;
            nb.extraTags = r.extraTags;
            nb.submit = r.decompose || true;                              // analysis always runs; `decompose` picks whether stems are made
            nb.decomposer = r.decompose ? (r.decomposer.isEmpty() ? model.settings().decomposer() : r.decomposer) : String ("skip");
            runBake (std::move (nb), r.rawNotation.isEmpty() ? String ("Bake") : r.rawNotation);
        };
        auto* raw = card.get();
        showDialog (std::move (card));
        raw->focusFirst();
    }

    void GnumbatEditor::runBake (NewBake nb, const String& label)
    {
        const auto root = model.root();
        auto settings = model.settings().deepCopy();
        nb.handoff.enabled = handoffActive();
        nb.handoff.ebysRoot = settings.ebysRoot();
        notify ("writing Bake ...");
        juce::Thread::launch ([nb = std::move (nb), root, settings, label, safe = juce::Component::SafePointer<GnumbatEditor> (this)]() mutable
        {
            String id, warn, hs;
            Library lib (root);
            auto r = lib.createBake (nb, id, &warn);
            if (r.wasOk()) hs = json::getString (lib.readBake (id), "handoff/status");
            if (r.wasOk() && settings.autostartWorker()) launchWorker (settings, root);
            juce::MessageManager::callAsync ([safe, r, id, label, warn, hs]
            {
                if (safe != nullptr) safe->bakeFinished (r, id, label, warn, hs);
            });
        });
    }

    void GnumbatEditor::bakeFinished (const juce::Result& r, const String& id, const String& label, const String& warning, const String& handoffStatus)
    {
        if (r.failed()) { notify ("BAKE FAILED: " + r.getErrorMessage(), true); return; }
        model.refreshNow();
        model.setSelection ({ id }, id);
        String msg = "baked " + ids::shortId (id) + "  \"" + label.substring (0, 40) + "\"";
        msg << (handoffStatus == "written" ? "  -> sent to EBYS raw_uploads: its Demucs + FluCoMa take over; analysis here starts now"
                                           : "  - stems + analysis are queued");
        if (warning.isNotEmpty()) msg << "   ! " << warning;
        notify (msg, warning.isNotEmpty());
    }

    // ---------------------------------------------------------------------------------------------------------- import / drag & drop
    static bool decodeAudio (const juce::File& f, CapturedAudio& out, String& err)
    {
        juce::AudioFormatManager fm;
        fm.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> rd (fm.createReaderFor (f));
        if (rd == nullptr) { err = "cannot read " + f.getFileName() + " (unsupported or corrupt)"; return false; }
        if (rd->sampleRate < 8000.0 || rd->lengthInSamples < 1) { err = f.getFileName() + " is empty"; return false; }
        if ((double) rd->lengthInSamples / rd->sampleRate > 20.0 * 60.0) { err = f.getFileName() + " is longer than 20 minutes - trim it first (a Bake is a musical phrase, not an album)"; return false; }
        const int n = (int) rd->lengthInSamples;
        juce::AudioBuffer<float> buf ((int) rd->numChannels, n);
        if (! rd->read (&buf, 0, n, 0, true, true)) { err = "read error in " + f.getFileName(); return false; }
        out.sampleRate = rd->sampleRate;
        out.channels.resize ((size_t) buf.getNumChannels());
        for (int c = 0; c < buf.getNumChannels(); ++c)
            out.channels[(size_t) c].assign (buf.getReadPointer (c), buf.getReadPointer (c) + n);
        return true;
    }

    bool GnumbatEditor::isInterestedInFileDrag (const juce::StringArray& files)
    {
        juce::AudioFormatManager fm;
        fm.registerBasicFormats();
        for (auto& f : files) if (fm.findFormatForFileExtension (juce::File (f).getFileExtension()) != nullptr) return dialog == nullptr;
        return false;
    }

    void GnumbatEditor::filesDropped (const juce::StringArray& files, int, int)
    {
        juce::Array<juce::File> fs;
        for (auto& f : files) fs.add (juce::File (f));
        beginImport (fs);
    }

    void GnumbatEditor::beginImport (const juce::Array<juce::File>& files)
    {
        if (! model.hasLibrary()) { notify ("Choose a library folder first (top bar).", true); return; }
        for (auto& f : files) if (f.existsAsFile()) importQueue.add (f);
        if (dialog == nullptr) importNext();
    }

    void GnumbatEditor::importNext()
    {
        if (importQueue.isEmpty() || dialog != nullptr) return;
        const auto file = importQueue.removeAndReturn (0);
        notify ("reading " + file.getFileName() + " ...");
        juce::Thread::launch ([file, safe = juce::Component::SafePointer<GnumbatEditor> (this)]
        {
            auto audio = std::make_shared<CapturedAudio>();
            String err;
            const bool ok = decodeAudio (file, *audio, err);
            juce::MessageManager::callAsync ([safe, file, audio, ok, err]
            {
                if (safe == nullptr) return;
                if (! ok) { safe->notify (err, true); safe->importNext(); return; }
                auto& me = *safe;
                const String detail = file.getFileName() + "   ·   " + String ((double) audio->frames() / audio->sampleRate, 2) + " s   ·   " + String (audio->numChannels()) + " ch   ·   imported";
                auto card = std::make_unique<ui::NotationCard> ("Notate imported audio", detail, file.getFileNameWithoutExtension(), me.model.lib().listProfiles(), me.lastProfileId, me.decomposerChoices(), true, juce::String(), me.autoLabel());
                card->onDone = [&me, audio, file] (ui::NotationCard::Result r)
                {
                    me.closeDialogSoon();
                    if (r.accepted)
                    {
                        me.lastProfileId = json::getString (r.profile, "profile_id", "np_freeform");
                        NewBake nb;
                        nb.audio = std::move (*audio);
                        nb.isImport = true;
                        nb.importOriginalName = file.getFileName();
                        nb.importSourcePath = file.getFullPathName();
                        nb.rawNotation = r.rawNotation;
                        nb.profile = r.profile;
                        nb.extraTags = r.extraTags;
                        nb.decomposer = r.decompose ? (r.decomposer.isEmpty() ? me.model.settings().decomposer() : r.decomposer) : String ("skip");
                        me.runBake (std::move (nb), r.rawNotation.isEmpty() ? file.getFileNameWithoutExtension() : r.rawNotation);
                    }
                    juce::MessageManager::callAsync ([safe = juce::Component::SafePointer<GnumbatEditor> (&me)] { if (safe != nullptr) safe->importNext(); });
                };
                auto* raw = card.get();
                me.showDialog (std::move (card));
                raw->focusFirst();
            });
        });
    }

    bool GnumbatEditor::shouldDropFilesWhenDraggedExternally (const juce::DragAndDropTarget::SourceDetails& d, juce::StringArray& files, bool& canMove)
    {
        if (json::getString (d.description, "kind") != "bakes" || ! model.hasLibrary()) return false;
        if (auto* ids_ = d.description.getProperty ("ids", {}).getArray())
            for (auto& id : *ids_)
            {
                const auto f = model.lib().audioFile (id.toString());
                if (f.existsAsFile()) files.add (f.getFullPathName());
            }
        canMove = false;
        return ! files.isEmpty();
    }
}
