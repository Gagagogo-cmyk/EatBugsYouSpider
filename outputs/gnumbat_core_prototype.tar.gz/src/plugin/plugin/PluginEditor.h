#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"
#include "ui/Theme.h"
#include "ui/AppModel.h"
#include "ui/UiHost.h"
#include "ui/CapturePanel.h"
#include "ui/BankView.h"
#include "ui/MapView.h"
#include "ui/InspectorView.h"

namespace gnumbat
{
    class GnumbatEditor final : public juce::AudioProcessorEditor,
                                public ui::UiHost,
                                public juce::DragAndDropContainer,
                                public juce::FileDragAndDropTarget,
                                private juce::ChangeListener,
                                private juce::Timer
    {
    public:
        explicit GnumbatEditor (GnumbatProcessor&);
        ~GnumbatEditor() override;

        void paint (juce::Graphics&) override;
        void resized() override;
        bool keyPressed (const juce::KeyPress&) override;

        // UiHost
        void prompt (const juce::String&, const juce::String&, const juce::Array<ui::PromptField>&, const juce::String&, std::function<void (juce::StringArray)>) override;
        void confirm (const juce::String&, const juce::String&, const juce::String&, std::function<void()>, bool danger) override;
        void notify (const juce::String&, bool isError = false) override;

        // drag & drop
        bool isInterestedInFileDrag (const juce::StringArray&) override;
        void filesDropped (const juce::StringArray&, int, int) override;
        bool shouldDropFilesWhenDraggedExternally (const juce::DragAndDropTarget::SourceDetails&, juce::StringArray&, bool&) override;

        // exposed for tests
        ui::AppModel& appModel() { return model; }
        void showTab (bool map);
        void refreshEbys();                                   // re-read the linked EBYS folder + active session (also called by a timer)
        bool handoffActive() const;
        juce::String ebysButtonText() const { return ebysButton.getButtonText(); }
        void beginBake();                              // same path as the BAKE button
        void beginImport (const juce::Array<juce::File>&);
        bool dialogOpen() const { return dialog != nullptr; }
        ui::CapturePanel& capturePanel() { return capture; }
        ui::MapView& mapView() { return mapPane; }
        ui::BankView& bankView() { return bankPane; }

    private:
        GnumbatProcessor& proc;
        ui::TerminalLookAndFeel laf;
        ui::AppModel model;
        ui::CapturePanel capture;
        ui::BankView bankPane;
        ui::MapView mapPane;
        ui::InspectorView inspector;
        juce::TooltipWindow tooltip { this, 500 };
        juce::TextButton ebysButton, libraryButton, bankTab { "BANK" }, mapTab { "MAP" }, workerButton { "START WORKER" };
        std::unique_ptr<juce::Component> dialog;
        std::unique_ptr<juce::FileChooser> chooser;
        bool mapShown = false;
        juce::String status;
        bool statusIsError = false;
        juce::int64 statusUntil = 0;
        juce::Rectangle<int> headerRect, tabsRect, ledRect;
        juce::Array<juce::File> importQueue;
        juce::String lastProfileId = "np_freeform";
        bool ebysOk = false;                 // EBYS folder linked, valid, and hand-off enabled state is read via handoffActive()
        juce::String ebysSession;
        juce::int64 lastEbysCheck = 0;

        void changeListenerCallback (juce::ChangeBroadcaster*) override;
        void timerCallback() override;
        void showDialog (std::unique_ptr<juce::Component>);
        void closeDialogSoon();
        void chooseLibrary();
        void chooseEbys();
        juce::String autoLabel() const;
        void restoreUi();
        void saveUi();
        void importNext();
        void runBake (NewBake, const juce::String& label);
        void bakeFinished (const juce::Result&, const juce::String& id, const juce::String& label, const juce::String& warning, const juce::String& handoffStatus);
        juce::StringArray decomposerChoices() const;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GnumbatEditor)
    };
}
