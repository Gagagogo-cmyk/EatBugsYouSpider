#include "BankView.h"
#include "../../core/Ids.h"
#include "../../core/JsonIo.h"
#include "Theme.h"

namespace gnumbat::ui
{
    using juce::String;
    using juce::var;

    enum Col { cState = 1, cId, cNotation, cTags, cBpm, cLen, cPipe, cSets, cAge };

    BankView::BankView (AppModel& m, UiHost& h) : model (m), host (h), bar (m, h)
    {
        addAndMakeVisible (bar);
        auto& hd = table.getHeader();
        hd.addColumn ("", cState, 24, 24, 24, juce::TableHeaderComponent::notSortable);
        hd.addColumn ("ID", cId, 72, 60, 100, juce::TableHeaderComponent::defaultFlags);
        hd.addColumn ("NOTATION", cNotation, 260, 100, 1000, juce::TableHeaderComponent::defaultFlags);
        hd.addColumn ("TAGS", cTags, 170, 60, 500, juce::TableHeaderComponent::defaultFlags);
        hd.addColumn ("BPM", cBpm, 54, 40, 90, juce::TableHeaderComponent::defaultFlags);
        hd.addColumn ("LEN", cLen, 58, 40, 90, juce::TableHeaderComponent::defaultFlags);
        hd.addColumn ("PIPELINE", cPipe, 108, 60, 200, juce::TableHeaderComponent::notSortable);
        hd.addColumn ("SETS", cSets, 120, 50, 300, juce::TableHeaderComponent::defaultFlags);
        hd.addColumn ("AGE", cAge, 56, 40, 90, juce::TableHeaderComponent::defaultFlags);
        hd.setSortColumnId (cAge, false);
        table.setHeaderHeight (22);
        table.setRowHeight (22);
        table.setMultipleSelectionEnabled (true);
        table.setColour (juce::ListBox::backgroundColourId, col::bg);
        addAndMakeVisible (table);
        model.addChangeListener (this);
        changeListenerCallback (nullptr);
    }

    BankView::~BankView() { model.removeChangeListener (this); }

    void BankView::resized()
    {
        auto r = getLocalBounds();
        bar.setBounds (r.removeFromTop (bar.heightForWidth (r.getWidth())));
        r.removeFromTop (4);
        table.setBounds (r);
    }

    void BankView::paint (juce::Graphics& g)
    {
        g.fillAll (col::bg);
        if (model.visible().empty())
        {
            g.setColour (col::dim);
            g.setFont (mono (13.0f));
            auto area = table.getBounds().withTrimmedTop (30);
            g.drawFittedText (model.rows().empty()
                                  ? "The bank is empty.\n\nCapture audio with BAKE above, or drop audio files onto this window."
                                  : "No Bake matches the current search / filters.",
                              area.reduced (30), juce::Justification::centredTop, 4);
        }
    }

    const BakeRow* BankView::rowAt (int row) const
    {
        const auto& v = model.visible();
        return row >= 0 && row < (int) v.size() ? &model.rows()[(size_t) v[(size_t) row]] : nullptr;
    }

    void BankView::changeListenerCallback (juce::ChangeBroadcaster*)
    {
        table.updateContent();
        // mirror the model's selection into the table without echoing it back
        syncing = true;
        juce::SparseSet<int> sel;
        for (int i = 0; i < getNumRows(); ++i)
            if (model.selection().contains (rowAt (i)->id)) sel.addRange ({ i, i + 1 });
        table.setSelectedRows (sel, juce::dontSendNotification);
        syncing = false;
        table.repaint();
        repaint();
        resized();
    }

    void BankView::sortOrderChanged (int c, bool fwd)
    {
        static const std::map<int, const char*> keys { { cId, "id" }, { cNotation, "notation" }, { cTags, "tags" }, { cBpm, "tempo" },
                                                       { cLen, "length" }, { cSets, "datasets" }, { cAge, "created" } };
        if (auto it = keys.find (c); it != keys.end())
            model.setSort (it->second, c == cAge ? ! fwd : fwd);          // AGE ascending means newest first
    }

    void BankView::selectedRowsChanged (int)
    {
        if (syncing) return;
        juce::StringArray ids;
        const auto sel = table.getSelectedRows();
        for (int i = 0; i < sel.size(); ++i) if (auto* r = rowAt (sel[i])) ids.add (r->id);
        String primary;
        if (auto* r = rowAt (table.getLastRowSelected())) primary = r->id;
        model.setSelection (ids, primary);
    }

    void BankView::backgroundClicked (const juce::MouseEvent&) { table.deselectAllRows(); }

    String BankView::ageText (const String& id)
    {
        const auto secs = (juce::Time::currentTimeMillis() - ids::timeMs (id)) / 1000;
        if (secs < 90) return String (juce::jmax<juce::int64> (0, secs)) + "s";
        if (secs < 5400) return String (secs / 60) + "m";
        if (secs < 129600) return String (secs / 3600) + "h";
        return String (secs / 86400) + "d";
    }

    void BankView::paintRowBackground (juce::Graphics& g, int row, int, int, bool selected)
    {
        const auto* r = rowAt (row);
        if (selected) g.fillAll (col::select);
        else if (row % 2) g.fillAll (juce::Colour (0xff0d1114));
        if (r != nullptr && r->id == model.hover()) { g.setColour (col::amber.withAlpha (0.14f)); g.fillAll(); }
    }

    void BankView::paintCell (juce::Graphics& g, int row, int c, int w, int h, bool selected)
    {
        const auto* r = rowAt (row);
        if (r == nullptr) return;
        const auto& v = r->view;
        const auto state = json::getString (v, "state");
        g.setFont (mono (12.5f));
        auto text = [&] (const String& s, juce::Colour colour, juce::Justification j = juce::Justification::centredLeft)
        {
            g.setColour (colour);
            g.drawText (s, 4, 0, w - 8, h, j, true);
        };
        switch (c)
        {
            case cState:
            {
                const auto colour = col::forState (state);
                g.setColour (colour);
                const float d = 9.0f;
                juce::Rectangle<float> dot (((float) w - d) * 0.5f, ((float) h - d) * 0.5f, d, d);
                if (state == "READY") g.fillEllipse (dot);
                else if (state == "ERROR") { g.drawLine (dot.getX(), dot.getY(), dot.getRight(), dot.getBottom(), 2.0f); g.drawLine (dot.getX(), dot.getBottom(), dot.getRight(), dot.getY(), 2.0f); }
                else g.drawEllipse (dot, 1.6f);
                break;
            }
            case cId:       text (ids::shortId (r->id), col::dim); break;
            case cNotation:
            {
                auto n = json::getString (v, "notation");
                text (n.isEmpty() ? String ("(no notation)") : n.replaceCharacter ('\n', ' '), n.isEmpty() ? col::dim : (selected ? col::green : col::text));
                break;
            }
            case cTags:     text (json::getStrings (v, "tags").joinIntoString (" · "), col::cyan.withAlpha (0.85f)); break;
            case cBpm:      text (AppModel::tempoText (v), json::isNumber (json::get (v, "fields/tempo")) ? col::amber : col::dim, juce::Justification::centredRight); break;
            case cLen:      text (String (json::getNumber (v, "duration_s"), 1) + "s", col::text, juce::Justification::centredRight); break;
            case cPipe:
            {
                if (state == "DECOMPOSING" || state == "ANALYZING")
                {
                    const float f = (float) json::getNumber (v, "progress");
                    auto track = juce::Rectangle<float> (4.0f, (float) h * 0.5f - 3.0f, (float) w - 8.0f, 6.0f);
                    g.setColour (col::line);  g.fillRect (track);
                    g.setColour (col::amber); g.fillRect (track.withWidth (track.getWidth() * juce::jlimit (0.03f, 1.0f, f)));
                }
                else if (state == "ERROR") text (json::getString (v, "error").upToFirstOccurrenceOf (":", false, false), col::red);
                else if (state == "READY")
                {
                    const int ns = json::get (v, "stems").getArray() != nullptr ? json::get (v, "stems").getArray()->size() : 0;
                    const bool waiting = json::getString (v, "handoff") == "waiting";
                    text ((waiting ? String ("EBYS...") : String (ns) + " stems") + " · " + String ((int) json::getNumber (v, "analysis/n_slices")) + " sl",
                          waiting ? col::amber : col::green.withAlpha (0.85f));
                }
                else text (state == "CAPTURED" ? (model.snapshot().worker.alive ? "queued" : "no worker") : state.toLowerCase(), state == "CAPTURED" && ! model.snapshot().worker.alive ? col::amber : col::dim);
                break;
            }
            case cSets:
            {
                auto ds = json::getStrings (v, "datasets"), ms = json::getStrings (v, "models");
                String t;
                if (! ds.isEmpty()) t << "ds:" << ds.joinIntoString (",");
                if (! ms.isEmpty()) t << (t.isEmpty() ? "" : " ") << "md:" << ms.joinIntoString (",");
                text (t, ms.isEmpty() ? col::violet : col::green);
                break;
            }
            case cAge:      text (ageText (r->id), col::dim, juce::Justification::centredRight); break;
            default: break;
        }
    }

    String BankView::getCellTooltip (int row, int c)
    {
        const auto* r = rowAt (row);
        if (r == nullptr) return {};
        const auto& v = r->view;
        if (c == cPipe && json::getString (v, "state") == "ERROR") return json::getString (v, "error");
        if (c == cNotation) return json::getString (v, "notation");
        if (c == cState) return json::getString (v, "state");
        if (c == cBpm) return json::isNumber (json::get (v, "fields/tempo")) ? "from notation / user" : "~ estimated (host or analysis)";
        return {};
    }

    var BankView::getDragSourceDescription (const juce::SparseSet<int>& rows)
    {
        juce::Array<var> ids;
        for (int i = 0; i < rows.size(); ++i) if (auto* r = rowAt (rows[i])) ids.add (r->id);
        return ids.isEmpty() ? var() : json::object ({ { "kind", "bakes" }, { "ids", var (ids) } });
    }

    void BankView::cellClicked (int row, int, const juce::MouseEvent& e)
    {
        if (! e.mods.isPopupMenu()) return;
        if (! table.isRowSelected (row)) table.selectRow (row);
        showContextMenu (model, host, &table, model.selection());
    }

    void BankView::cellDoubleClicked (int row, int, const juce::MouseEvent&)
    {
        if (auto* r = rowAt (row)) promptEditNotation (model, host, r->id);
    }

    bool BankView::keyPressed (const juce::KeyPress& k)
    {
        const auto& sel = model.selection();
        if ((k == juce::KeyPress::deleteKey || k == juce::KeyPress::backspaceKey) && ! sel.isEmpty()) { confirmTrash (model, host, sel); return true; }
        if (k == juce::KeyPress ('z', juce::ModifierKeys::commandModifier, 0) && model.canUndoTrash()) { model.undoTrash(); return true; }
        if (k == juce::KeyPress ('f', juce::ModifierKeys::commandModifier, 0) || k == juce::KeyPress ('/')) { bar.focusSearch(); return true; }
        if (k == juce::KeyPress::returnKey && sel.size() == 1) { promptEditNotation (model, host, sel[0]); return true; }
        return false;
    }

    // ---- shared actions ------------------------------------------------------------------------------------------
    void BankView::promptEditNotation (AppModel& m, UiHost& host, const String& id)
    {
        const auto* row = m.rowById (id);
        if (row == nullptr) return;
        const auto cur = json::getString (row->view, "notation");
        host.prompt ("Rename / re-notate", "The notation is your own words. Old text is kept in this Bake's history.\n" + ids::shortId (id),
                     juce::Array<PromptField> { PromptField { "NOTATION", cur, "", true }, PromptField { "RE-DERIVE TAGS FROM IT?  type yes to replace the tags with the profile's parse", "", "leave empty to keep the current tags", false } },
                     "SAVE", [&m, &host, id] (juce::StringArray v)
        {
            SemanticEdit e;
            e.setRawNotation = true; e.rawNotation = v[0];
            e.reparse = v[1].trim().equalsIgnoreCase ("yes") || v[1].trim().equalsIgnoreCase ("y");
            if (auto err = m.editSemantic ({ id }, e); err.isNotEmpty()) host.notify (err, true);
        });
    }

    void BankView::promptAddTag (AppModel& m, UiHost& host, const juce::StringArray& ids_)
    {
        host.prompt ("Add tag", String (ids_.size()) + " Bake" + (ids_.size() == 1 ? "" : "s") + " - separate several tags with commas",
                     { { "TAGS", "", "e.g. riser, dark, tension", false } }, "ADD", [&m, &host, ids_] (juce::StringArray v)
        {
            SemanticEdit e;
            for (auto& t : juce::StringArray::fromTokens (v[0], ",", "")) if (t.trim().isNotEmpty()) e.addTags.add (t.trim());
            if (e.addTags.isEmpty()) return;
            if (auto err = m.editSemantic (ids_, e); err.isNotEmpty()) host.notify (err, true);
        });
    }

    void BankView::promptAddGroup (AppModel& m, UiHost& host, const juce::StringArray& ids_)
    {
        host.prompt ("Add to group", "Groups are just names you choose - a Bake can be in several.",
                     { { "GROUP", "", "e.g. risers", false } }, "ADD", [&m, &host, ids_] (juce::StringArray v)
        {
            SemanticEdit e;
            if (v[0].trim().isEmpty()) return;
            e.addGroups.add (v[0].trim());
            if (auto err = m.editSemantic (ids_, e); err.isNotEmpty()) host.notify (err, true);
        });
    }

    void BankView::promptSetField (AppModel& m, UiHost& host, const juce::StringArray& ids_)
    {
        host.prompt ("Set field", "Your own structured value on " + String (ids_.size()) + " Bake(s). Numbers are stored as numbers.",
                     juce::Array<PromptField> { PromptField { "NAME", "", "e.g. density_class", false }, PromptField { "VALUE", "", "empty = remove the field", false } }, "SET", [&m, &host, ids_] (juce::StringArray v)
        {
            const auto name = v[0].trim(), val = v[1].trim();
            if (name.isEmpty() || name.containsChar ('/') || name.length() > 64) { host.notify ("field names must be 1-64 characters and cannot contain '/'", true); return; }
            SemanticEdit e;
            if (val.isEmpty()) e.removeFields.add (name);
            else
            {
                var x = val;
                if (val.containsOnly ("0123456789.-+") && val.containsAnyOf ("0123456789")) x = val.getDoubleValue();
                else if (val.equalsIgnoreCase ("true")) x = true;
                else if (val.equalsIgnoreCase ("false")) x = false;
                e.setFields = json::object ({ { name.toRawUTF8(), x } });
            }
            if (auto err = m.editSemantic (ids_, e); err.isNotEmpty()) host.notify (err, true);
        });
    }

    void BankView::promptDatasetMenu (AppModel& m, UiHost& host, juce::Component* target, const juce::StringArray& ids_)
    {
        juce::PopupMenu menu;
        const auto sets = m.snapshot().datasets;
        for (int i = 0; i < sets.size(); ++i) menu.addItem (100 + i, sets[i].name + "  (" + String (sets[i].members) + ")");
        if (! sets.isEmpty()) menu.addSeparator();
        menu.addItem (1, "New dataset...");
        menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (target), [&m, &host, ids_, sets] (int r)
        {
            if (r == 1)
                host.prompt ("New dataset", "A dataset is a named working set of Bakes. Training uses immutable versions of it.",
                             { { "NAME", "", "e.g. risers v1", false } }, "CREATE", [&m, &host, ids_] (juce::StringArray v)
                {
                    if (auto err = m.createDatasetWith (v[0], ids_); err.isNotEmpty()) host.notify (err, true);
                });
            else if (r >= 100 && r - 100 < sets.size())
                if (auto err = m.addToDataset (sets[r - 100].id, ids_); err.isNotEmpty()) host.notify (err, true);
        });
    }

    void BankView::confirmTrash (AppModel& m, UiHost& host, const juce::StringArray& ids_)
    {
        const auto pinned = m.lib().bakesPinnedByDatasetVersions();
        int nPinned = 0;
        for (auto& id : ids_) if (pinned.count (id)) ++nPinned;
        String msg = "Move " + String (ids_.size()) + " Bake" + (ids_.size() == 1 ? "" : "s") + " to the library's .trash folder? You can undo this with Ctrl/Cmd+Z during this session.";
        if (nPinned > 0)
            msg << "\n\nWARNING: " << nPinned << " of them are pinned by dataset versions. Removing them means those versions can no longer be exported or retrained exactly.";
        host.confirm ("Delete Bakes", msg, "DELETE", [&m, &host, ids_]
        {
            if (auto err = m.trash (ids_); err.isNotEmpty()) host.notify (err, true);
        }, true);
    }

    void BankView::showContextMenu (AppModel& m, UiHost& host, juce::Component* target, const juce::StringArray& ids_)
    {
        if (ids_.isEmpty()) return;
        const bool one = ids_.size() == 1;
        juce::PopupMenu menu;
        menu.addSectionHeader (one ? ids::shortId (ids_[0]) : String (ids_.size()) + " Bakes");
        if (one) menu.addItem (1, "Rename / re-notate...");
        menu.addItem (2, "Add tag...");
        juce::PopupMenu rm;
        juce::StringArray tags;
        for (auto& id : ids_) if (auto* r = m.rowById (id)) for (auto& t : json::getStrings (r->view, "tags")) if (! tags.contains (t, true)) tags.add (t);
        for (int i = 0; i < tags.size() && i < 40; ++i) rm.addItem (1000 + i, tags[i]);
        menu.addSubMenu ("Remove tag", rm, ! tags.isEmpty());
        menu.addItem (3, "Set field...");
        menu.addItem (4, "Add to group...");
        menu.addSeparator();
        menu.addItem (5, "Add to dataset (-> models)...");
        juce::PopupMenu rd;
        juce::StringArray dsNames;
        for (auto& id : ids_) if (auto* r = m.rowById (id)) for (auto& d : json::getStrings (r->view, "datasets")) if (! dsNames.contains (d)) dsNames.add (d);
        for (int i = 0; i < dsNames.size(); ++i) rd.addItem (2000 + i, dsNames[i]);
        menu.addSubMenu ("Remove from dataset", rd, ! dsNames.isEmpty());
        menu.addSeparator();
        juce::PopupMenu rel;
        rel.addItem (3001, "same dataset");  rel.addItem (3002, "same model");  rel.addItem (3003, "same group");  rel.addItem (3004, "sharing a tag");
        menu.addSubMenu ("Select related", rel, one);
        juce::PopupMenu rp;
        rp.addItem (4001, "everything (stems + analysis)");  rp.addItem (4002, "stems only");  rp.addItem (4003, "analysis only");
        menu.addSubMenu ("Reprocess", rp);
        menu.addSeparator();
        if (one) menu.addItem (6, "Reveal in file manager");
        menu.addItem (7, "Copy id");
        menu.addItem (8, "Delete...");
        menu.addItem (9, "Undo delete", m.canUndoTrash());

        menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (target), [&m, &host, target, ids_, tags, dsNames] (int r)
        {
            if (r == 1) promptEditNotation (m, host, ids_[0]);
            else if (r == 2) promptAddTag (m, host, ids_);
            else if (r == 3) promptSetField (m, host, ids_);
            else if (r == 4) promptAddGroup (m, host, ids_);
            else if (r == 5) promptDatasetMenu (m, host, target, ids_);
            else if (r == 6) m.lib().bakeDir (ids_[0]).revealToUser();
            else if (r == 7) juce::SystemClipboard::copyTextToClipboard (ids_.joinIntoString ("\n"));
            else if (r == 8) confirmTrash (m, host, ids_);
            else if (r == 9) m.undoTrash();
            else if (r >= 1000 && r < 2000)
            {
                SemanticEdit e; e.removeTags.add (tags[r - 1000]);
                if (auto err = m.editSemantic (ids_, e); err.isNotEmpty()) host.notify (err, true);
            }
            else if (r >= 2000 && r < 3000)
            {
                for (auto& d : m.snapshot().datasets) if (d.name == dsNames[r - 2000]) { m.removeFromDataset (d.id, ids_); break; }
            }
            else if (r >= 3001 && r <= 3004)
            {
                const char* kinds[] = { "dataset", "model", "group", "tag" };
                auto related = m.relatedIds (kinds[r - 3001], ids_[0]);
                m.setSelection (related, ids_[0]);
                host.notify (String (related.size()) + " related Bakes selected");
            }
            else if (r >= 4001 && r <= 4003)
            {
                if (auto err = m.reprocess (ids_, r == 4001 ? "all" : r == 4002 ? "decompose" : "analyze"); err.isNotEmpty()) host.notify (err, true);
            }
        });
    }
}
