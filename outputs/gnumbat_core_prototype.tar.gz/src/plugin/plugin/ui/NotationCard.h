#pragma once
// "Notate this Bake" dialog. The user writes free-form notation (or nothing). It is stored EXACTLY as typed.
// A notation profile is optional, user-chosen, and only ever DERIVES tags/fields (shown live below) — it never
// rewrites the raw text and is never required.
#include <juce_gui_basics/juce_gui_basics.h>
#include "Theme.h"

namespace gnumbat::ui
{
    class NotationCard : public juce::Component, private juce::TextEditor::Listener
    {
    public:
        struct Result
        {
            bool accepted = false;
            juce::String rawNotation;
            juce::var profile;                       // void => freeform
            juce::StringArray extraTags;
            bool decompose = true;
            juce::String decomposer;                 // "" => use the setting
        };

        NotationCard (const juce::String& heading, const juce::String& detailLine, const juce::String& initialNotation,
                      const juce::Array<juce::var>& profiles, const juce::String& initialProfileId,
                      const juce::StringArray& decomposers, bool offerDecompose,
                      const juce::String& warning = {}, const juce::String& autoLabel = "auto");

        std::function<void (Result)> onDone;
        void focusFirst() { if (isShowing()) notation.grabKeyboardFocus(); }

        void paint (juce::Graphics&) override;
        void resized() override;
        bool keyPressed (const juce::KeyPress&) override;
        void mouseDown (const juce::MouseEvent&) override {}

    private:
        juce::String heading, detail, warning;
        juce::TextEditor notation, extra;
        juce::ComboBox profileBox, decompBox;
        juce::ToggleButton decompose { "separate stems (drums / bass / body / vocals)" };
        juce::TextButton okButton { "BAKE" }, cancelButton { "CANCEL" };
        juce::Array<juce::var> profileList;
        juce::StringArray previewTags;
        juce::String previewFields, previewError;
        juce::Rectangle<int> card, previewArea;
        bool offer;

        void textEditorTextChanged (juce::TextEditor&) override { updatePreview(); }
        void updatePreview();
        void finish (bool ok);
        juce::var currentProfile() const;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NotationCard)
    };
}
