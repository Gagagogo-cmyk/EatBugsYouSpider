#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "UiHost.h"

namespace gnumbat::ui
{
    /** Host detection + range definition + BAKE. A plugin cannot render the host timeline, so a range is captured by
        PLAYING it through the plugin: the coverage bar shows how much of IN..OUT has actually been heard. */
    class CapturePanel : public juce::Component, private juce::Timer
    {
    public:
        CapturePanel (GnumbatProcessor&, UiHost&);
        ~CapturePanel() override;
        void paint (juce::Graphics&) override;
        void resized() override;
        std::function<void()> onBake, onImport;
        void refreshFromPlan();                       // after state restore

        static juce::String formatMarker (const Marker&, const TransportSnapshot&);
        static bool parseMarker (const juce::String& text, const Marker& now, const TransportSnapshot&, Marker& out);

    private:
        GnumbatProcessor& proc;
        UiHost& host;
        juce::TextButton modeButtons[4];
        juce::TextButton setIn { "SET IN" }, setOut { "SET OUT" }, inMinus { "-" }, inPlus { "+" }, outMinus { "-" }, outPlus { "+" };
        juce::TextButton bake { "BAKE" }, import_ { "IMPORT..." };
        juce::TextEditor inEdit, outEdit, barsEdit, secsEdit;
        double coverage = 0.0;
        TransportSnapshot t;
        juce::Rectangle<int> coverageRect, meterRect, hostRect;
        juce::String lastInText, lastOutText;

        void timerCallback() override;
        void selectMode (CapturePlan::Mode);
        void nudge (Marker&, int direction, bool bar);
        void commitEdit (bool isIn);
        void layoutForMode();
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (CapturePanel)
    };
}
