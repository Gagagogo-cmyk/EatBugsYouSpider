#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace gnumbat::ui
{
    // Terminal palette: near-black, phosphor green primary, amber for attention, restrained colour elsewhere.
    namespace col
    {
        const juce::Colour bg       { 0xff0b0e10 };
        const juce::Colour panel    { 0xff11161a };
        const juce::Colour panelHi  { 0xff182027 };
        const juce::Colour line     { 0xff2a343c };
        const juce::Colour text     { 0xffc9d3cb };
        const juce::Colour dim      { 0xff6f7d76 };
        const juce::Colour green    { 0xff5fd38d };
        const juce::Colour amber    { 0xfff0b13c };
        const juce::Colour red      { 0xffe5534b };
        const juce::Colour cyan     { 0xff56b6c2 };
        const juce::Colour violet   { 0xffb48ead };
        const juce::Colour select   { 0xff1f3a2c };

        inline juce::Colour forState (const juce::String& s)
        {
            if (s == "READY") return green;
            if (s == "ERROR") return red;
            if (s == "CAPTURED") return dim;
            if (s == "DECOMPOSING" || s == "ANALYZING") return amber;
            return cyan;                                    // DECOMPOSED / ANALYZED: done a stage, waiting for the next
        }
    }

    inline juce::Font mono (float h, bool bold = false)
    {
        return juce::Font (juce::FontOptions (juce::Font::getDefaultMonospacedFontName(), h, bold ? juce::Font::bold : juce::Font::plain));
    }

    class TerminalLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        TerminalLookAndFeel();
        juce::Font getTextButtonFont (juce::TextButton&, int h) override { return mono ((float) juce::jmin (13, h - 8), false); }
        juce::Font getLabelFont (juce::Label& l) override { return mono (l.getFont().getHeight()); }
        juce::Font getComboBoxFont (juce::ComboBox&) override { return mono (12.5f); }
        juce::Font getPopupMenuFont() override { return mono (12.5f); }
        void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&, bool over, bool down) override;
        void drawComboBox (juce::Graphics&, int w, int h, bool, int, int, int, int, juce::ComboBox&) override;
        void drawScrollbar (juce::Graphics&, juce::ScrollBar&, int x, int y, int w, int h, bool vertical, int thumbStart, int thumbSize, bool over, bool down) override;
        int getDefaultScrollbarWidth() override { return 9; }
        void drawTextEditorOutline (juce::Graphics&, int w, int h, juce::TextEditor&) override;
        void fillTextEditorBackground (juce::Graphics&, int w, int h, juce::TextEditor&) override;
        void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool over, bool down) override;
        void drawPopupMenuBackground (juce::Graphics&, int w, int h) override;
        void drawTooltip (juce::Graphics&, const juce::String&, int w, int h) override;
    };
}
