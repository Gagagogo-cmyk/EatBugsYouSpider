#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "AppModel.h"
#include "UiHost.h"
#include "Theme.h"

namespace gnumbat::ui
{
    /** Free-text search + removable filter chips + a builder driven by the fields that actually exist in this
        library (nothing assumes a particular field is present). Produces a filter AST on the AppModel. */
    class FilterBar : public juce::Component, private juce::ChangeListener, private juce::TextEditor::Listener
    {
    public:
        FilterBar (AppModel&, UiHost&);
        ~FilterBar() override;
        void paint (juce::Graphics&) override;
        void resized() override;
        void mouseUp (const juce::MouseEvent&) override;
        int heightForWidth (int w) const;
        void focusSearch() { search.grabKeyboardFocus(); }

    private:
        AppModel& model;
        UiHost& host;
        juce::TextEditor search;
        juce::TextButton addButton { "+ FILTER" }, clearButton { "CLEAR" };
        std::vector<std::pair<juce::Rectangle<int>, int>> chipRects;   // rect -> chip index
        juce::String countText;

        void changeListenerCallback (juce::ChangeBroadcaster*) override { updateCount(); repaint(); resizedIfChipsChanged(); }
        void textEditorTextChanged (juce::TextEditor&) override { model.setSearch (search.getText()); }
        void resizedIfChipsChanged();
        void updateCount();
        void showBuilder();
        void chooseOperator (const filter::FieldInfo&);
        void askValue (const filter::FieldInfo&, const juce::String& op);
        int lastChipCount = -1;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (FilterBar)
    };
}
