#include "Theme.h"

namespace gnumbat::ui
{
    TerminalLookAndFeel::TerminalLookAndFeel()
    {
        using C = juce::Colour;
        setColour (juce::ResizableWindow::backgroundColourId, col::bg);
        setColour (juce::Label::textColourId, col::text);
        setColour (juce::TextButton::buttonColourId, col::panel);
        setColour (juce::TextButton::buttonOnColourId, col::select);
        setColour (juce::TextButton::textColourOffId, col::text);
        setColour (juce::TextButton::textColourOnId, col::green);
        setColour (juce::TextEditor::backgroundColourId, C (0xff0e1215));
        setColour (juce::TextEditor::textColourId, col::text);
        setColour (juce::TextEditor::highlightColourId, C (0xff2c5b41));
        setColour (juce::TextEditor::highlightedTextColourId, col::text);
        setColour (juce::TextEditor::outlineColourId, col::line);
        setColour (juce::TextEditor::focusedOutlineColourId, col::green);
        setColour (juce::CaretComponent::caretColourId, col::green);
        setColour (juce::ComboBox::backgroundColourId, C (0xff0e1215));
        setColour (juce::ComboBox::textColourId, col::text);
        setColour (juce::ComboBox::outlineColourId, col::line);
        setColour (juce::ComboBox::arrowColourId, col::dim);
        setColour (juce::PopupMenu::backgroundColourId, C (0xff10161a));
        setColour (juce::PopupMenu::textColourId, col::text);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, col::select);
        setColour (juce::PopupMenu::highlightedTextColourId, col::green);
        setColour (juce::ScrollBar::thumbColourId, C (0xff3a4650));
        setColour (juce::TableHeaderComponent::backgroundColourId, col::panelHi);
        setColour (juce::TableHeaderComponent::textColourId, col::dim);
        setColour (juce::TableHeaderComponent::outlineColourId, col::line);
        setColour (juce::ListBox::backgroundColourId, col::bg);
        setColour (juce::ListBox::outlineColourId, col::line);
        setColour (juce::ToggleButton::textColourId, col::text);
        setColour (juce::ToggleButton::tickColourId, col::green);
        setColour (juce::TooltipWindow::backgroundColourId, col::panelHi);
        setColour (juce::TooltipWindow::textColourId, col::text);
        setColour (juce::TooltipWindow::outlineColourId, col::line);
        setColour (juce::AlertWindow::backgroundColourId, col::panel);
        setColour (juce::AlertWindow::textColourId, col::text);
        setColour (juce::AlertWindow::outlineColourId, col::line);
        setDefaultSansSerifTypefaceName (juce::Font::getDefaultMonospacedFontName());
    }

    void TerminalLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour& base, bool over, bool down)
    {
        auto r = b.getLocalBounds().toFloat().reduced (0.5f);
        auto fill = b.getToggleState() ? findColour (juce::TextButton::buttonOnColourId) : base;
        if (! b.isEnabled()) fill = fill.withAlpha (0.4f);
        else if (down) fill = fill.brighter (0.25f);
        else if (over) fill = fill.brighter (0.12f);
        g.setColour (fill);
        g.fillRect (r);
        g.setColour (b.getToggleState() ? col::green.withAlpha (0.7f) : (over ? col::dim : col::line));
        g.drawRect (r, 1.0f);
    }

    void TerminalLookAndFeel::drawComboBox (juce::Graphics& g, int w, int h, bool, int, int, int, int, juce::ComboBox& cb)
    {
        auto r = juce::Rectangle<float> (0.5f, 0.5f, (float) w - 1.0f, (float) h - 1.0f);
        g.setColour (findColour (juce::ComboBox::backgroundColourId));
        g.fillRect (r);
        g.setColour (cb.hasKeyboardFocus (true) ? col::green : col::line);
        g.drawRect (r, 1.0f);
        juce::Path p;
        const float cx = (float) w - 11.0f, cy = (float) h * 0.5f;
        p.addTriangle (cx - 3.5f, cy - 2.0f, cx + 3.5f, cy - 2.0f, cx, cy + 2.5f);
        g.setColour (cb.isEnabled() ? col::dim : col::line);
        g.fillPath (p);
    }

    void TerminalLookAndFeel::drawScrollbar (juce::Graphics& g, juce::ScrollBar&, int x, int y, int w, int h, bool vertical, int start, int size, bool over, bool down)
    {
        g.setColour (juce::Colour (0xff0e1215));
        g.fillRect (x, y, w, h);
        g.setColour (down ? col::green : (over ? col::dim : juce::Colour (0xff3a4650)));
        if (vertical) g.fillRect (x + 2, y + start, w - 4, size);
        else          g.fillRect (x + start, y + 2, size, h - 4);
    }

    void TerminalLookAndFeel::fillTextEditorBackground (juce::Graphics& g, int w, int h, juce::TextEditor& e)
    {
        g.setColour (e.findColour (juce::TextEditor::backgroundColourId));
        g.fillRect (0, 0, w, h);
    }

    void TerminalLookAndFeel::drawTextEditorOutline (juce::Graphics& g, int w, int h, juce::TextEditor& e)
    {
        g.setColour (e.hasKeyboardFocus (true) ? col::green.withAlpha (0.8f) : col::line);
        g.drawRect (0, 0, w, h, 1);
    }

    void TerminalLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool over, bool)
    {
        const float s = 12.0f;
        juce::Rectangle<float> box (2.0f, ((float) b.getHeight() - s) * 0.5f, s, s);
        g.setColour (col::line);
        g.drawRect (box, 1.0f);
        if (b.getToggleState()) { g.setColour (col::green); g.fillRect (box.reduced (3.0f)); }
        g.setColour (b.isEnabled() ? (over ? col::green : col::text) : col::dim);
        g.setFont (mono (12.5f));
        g.drawText (b.getButtonText(), b.getLocalBounds().withTrimmedLeft ((int) s + 8), juce::Justification::centredLeft, true);
    }

    void TerminalLookAndFeel::drawPopupMenuBackground (juce::Graphics& g, int w, int h)
    {
        g.fillAll (findColour (juce::PopupMenu::backgroundColourId));
        g.setColour (col::line);
        g.drawRect (0, 0, w, h, 1);
    }

    void TerminalLookAndFeel::drawTooltip (juce::Graphics& g, const juce::String& text, int w, int h)
    {
        g.fillAll (col::panelHi);
        g.setColour (col::line);
        g.drawRect (0, 0, w, h, 1);
        g.setColour (col::text);
        g.setFont (mono (12.0f));
        g.drawFittedText (text, 6, 3, w - 12, h - 6, juce::Justification::centredLeft, 6);
    }
}
