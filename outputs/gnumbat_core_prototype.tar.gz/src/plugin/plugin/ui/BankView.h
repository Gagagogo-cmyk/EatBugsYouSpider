#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "AppModel.h"
#include "UiHost.h"
#include "FilterBar.h"

namespace gnumbat::ui
{
    /** Bake Bank: browse / search / filter / multi-select / tag / group / rename / delete / assign to datasets.
        Dense one-line-per-Bake table (terminal style). Drag rows out to a DAW to drop the audio. */
    class BankView : public juce::Component, private juce::TableListBoxModel, private juce::ChangeListener
    {
    public:
        BankView (AppModel&, UiHost&);
        ~BankView() override;
        void resized() override;
        void paint (juce::Graphics&) override;
        bool keyPressed (const juce::KeyPress&) override;
        FilterBar& filterBar() { return bar; }

        // actions shared with the inspector and the map's context menu
        static void showContextMenu (AppModel&, UiHost&, juce::Component* target, const juce::StringArray& ids);
        static void promptEditNotation (AppModel&, UiHost&, const juce::String& id);
        static void promptAddTag (AppModel&, UiHost&, const juce::StringArray& ids);
        static void promptAddGroup (AppModel&, UiHost&, const juce::StringArray& ids);
        static void promptSetField (AppModel&, UiHost&, const juce::StringArray& ids);
        static void promptDatasetMenu (AppModel&, UiHost&, juce::Component* target, const juce::StringArray& ids);
        static void confirmTrash (AppModel&, UiHost&, const juce::StringArray& ids);

    private:
        AppModel& model;
        UiHost& host;
        FilterBar bar;
        juce::TableListBox table { "bank", this };
        bool syncing = false;

        int getNumRows() override { return (int) model.visible().size(); }
        void paintRowBackground (juce::Graphics&, int row, int w, int h, bool selected) override;
        void paintCell (juce::Graphics&, int row, int col, int w, int h, bool selected) override;
        void sortOrderChanged (int col, bool fwd) override;
        void selectedRowsChanged (int lastRow) override;
        void cellClicked (int row, int col, const juce::MouseEvent&) override;
        void cellDoubleClicked (int row, int col, const juce::MouseEvent&) override;
        juce::String getCellTooltip (int row, int col) override;
        juce::var getDragSourceDescription (const juce::SparseSet<int>&) override;
        void backgroundClicked (const juce::MouseEvent&) override;
        void changeListenerCallback (juce::ChangeBroadcaster*) override;
        const BakeRow* rowAt (int) const;
        static juce::String ageText (const juce::String& id);
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BankView)
    };
}
