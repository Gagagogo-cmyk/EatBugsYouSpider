#include "NotationCard.h"
#include "../../core/NotationProfile.h"
#include "../../core/JsonIo.h"

namespace gnumbat::ui
{
    NotationCard::NotationCard (const juce::String& h, const juce::String& d, const juce::String& initial,
                                const juce::Array<juce::var>& profiles, const juce::String& initialProfileId,
                                const juce::StringArray& decomposers, bool offerDecompose, const juce::String& warn, const juce::String& autoLabel)
        : heading (h), detail (d), warning (warn), profileList (profiles), offer (offerDecompose)
    {
        setWantsKeyboardFocus (true);
        notation.setMultiLine (true, true);
        notation.setReturnKeyStartsNewLine (false);
        notation.setFont (mono (14.0f));
        notation.setTextToShowWhenEmpty ("describe this sound in your own words - or leave it empty", col::dim);
        notation.setText (initial, false);
        notation.setSelectAllWhenFocused (true);
        notation.addListener (this);
        notation.onReturnKey = [this] { finish (true); };
        notation.onEscapeKey = [this] { finish (false); };
        addAndMakeVisible (notation);

        extra.setFont (mono (12.5f));
        extra.setTextToShowWhenEmpty ("extra tags, comma separated (optional)", col::dim);
        extra.onReturnKey = [this] { finish (true); };
        extra.onEscapeKey = [this] { finish (false); };
        addAndMakeVisible (extra);

        int sel = 1;
        for (int i = 0; i < profiles.size(); ++i)
        {
            const auto pid = json::getString (profiles[i], "profile_id");
            profileBox.addItem ((pid == "np_freeform" ? "freeform (default: no parsing)" : json::getString (profiles[i], "name", pid)), i + 1);
            if (pid == initialProfileId) sel = i + 1;
        }
        profileBox.setSelectedId (sel, juce::dontSendNotification);
        profileBox.onChange = [this] { updatePreview(); };
        addAndMakeVisible (profileBox);

        decompBox.addItem (autoLabel, 1);
        int id = 2;
        for (auto& d2 : decomposers) decompBox.addItem (d2, id++);
        decompBox.setSelectedId (1, juce::dontSendNotification);
        decompose.setToggleState (true, juce::dontSendNotification);
        if (offerDecompose) { addAndMakeVisible (decompose); addAndMakeVisible (decompBox); }

        okButton.setColour (juce::TextButton::buttonColourId, col::green.withAlpha (0.28f));
        okButton.onClick = [this] { finish (true); };
        cancelButton.onClick = [this] { finish (false); };
        addAndMakeVisible (okButton);
        addAndMakeVisible (cancelButton);
        updatePreview();
    }

    juce::var NotationCard::currentProfile() const
    {
        const int i = profileBox.getSelectedId() - 1;
        return i >= 0 && i < profileList.size() ? profileList[i] : notation::freeformProfile();
    }

    void NotationCard::updatePreview()
    {
        const auto profile = currentProfile();
        const auto parsed = notation::parse (notation.getText(), profile);
        previewTags = parsed.tags;
        previewError = parsed.error;
        juce::StringArray f;
        for (auto& k : parsed.fieldOrder) f.add (k + "=" + parsed.fields.getProperty (k, {}).toString());
        previewFields = f.joinIntoString ("  ");
        repaint (previewArea);
    }

    void NotationCard::finish (bool ok)
    {
        Result r;
        r.accepted = ok;
        r.rawNotation = notation.getText();              // verbatim: no trim, no normalisation
        r.profile = currentProfile();
        for (auto& t : juce::StringArray::fromTokens (extra.getText(), ",", "")) if (t.trim().isNotEmpty()) r.extraTags.add (t.trim());
        r.decompose = ! offer || decompose.getToggleState();
        r.decomposer = decompBox.getSelectedId() <= 1 ? juce::String() : decompBox.getText();
        if (onDone) onDone (r);
    }

    bool NotationCard::keyPressed (const juce::KeyPress& k)
    {
        if (k == juce::KeyPress::escapeKey) { finish (false); return true; }
        return true;
    }

    void NotationCard::paint (juce::Graphics& g)
    {
        g.fillAll (juce::Colours::black.withAlpha (0.62f));
        g.setColour (col::panel);           g.fillRect (card);
        g.setColour (col::green.withAlpha (0.55f)); g.drawRect (card, 1);
        auto r = card.reduced (20, 0);
        g.setColour (col::green);  g.setFont (mono (13.0f, true));
        g.drawText ("> " + heading.toUpperCase(), r.getX(), card.getY() + 12, r.getWidth(), 22, juce::Justification::centredLeft);
        g.setColour (col::dim);    g.setFont (mono (11.5f));
        g.drawText (detail, r.getX(), card.getY() + 34, r.getWidth(), 16, juce::Justification::centredLeft, true);
        int y = card.getY() + 54;
        if (warning.isNotEmpty())
        {
            g.setColour (col::amber); g.setFont (mono (12.0f));
            g.drawFittedText (warning, r.getX(), y, r.getWidth(), 34, juce::Justification::topLeft, 2);
        }
        g.setColour (col::dim);  g.setFont (mono (11.0f));
        g.drawText ("NOTATION  (stored exactly as typed)", r.getX(), notation.getY() - 16, r.getWidth(), 14, juce::Justification::centredLeft);
        g.drawText ("VOCABULARY PROFILE  (optional; only derives tags/fields below)", r.getX(), profileBox.getY() - 16, r.getWidth(), 14, juce::Justification::centredLeft);

        g.setColour (col::bg);   g.fillRect (previewArea);
        g.setColour (col::line); g.drawRect (previewArea, 1);
        auto pa = previewArea.reduced (8, 4);
        g.setFont (mono (12.0f));
        if (previewError.isNotEmpty()) { g.setColour (col::red); g.drawFittedText ("profile problem: " + previewError, pa, juce::Justification::topLeft, 3); return; }
        const bool freeform = json::getString (currentProfile(), "profile_id") == "np_freeform";
        g.setColour (col::dim);
        g.drawText (freeform ? "TAGS" : "PARSED TAGS", pa.removeFromTop (14), juce::Justification::centredLeft);
        g.setColour (previewTags.isEmpty() ? col::dim : col::cyan);
        g.drawFittedText (previewTags.isEmpty() ? juce::String ("(none)") : previewTags.joinIntoString ("  |  "), pa.removeFromTop (18), juce::Justification::centredLeft, 1);
        if (! freeform)
        {
            g.setColour (col::dim);  g.drawText ("FIELDS", pa.removeFromTop (14), juce::Justification::centredLeft);
            g.setColour (previewFields.isEmpty() ? col::dim : col::amber);
            g.drawFittedText (previewFields.isEmpty() ? juce::String ("(none)") : previewFields, pa, juce::Justification::topLeft, 2);
        }
    }

    void NotationCard::resized()
    {
        const int h = 64 + (warning.isNotEmpty() ? 38 : 0) + 18 + 84 + 8 + 30 + 10 + 18 + 26 + 8 + 66 + 8 + 26 + (offer ? 34 : 0) + 20 + 44;
        card = juce::Rectangle<int> (600, h).withCentre (getLocalBounds().getCentre());
        auto r = card.reduced (20, 0);
        int y = card.getY() + 54 + (warning.isNotEmpty() ? 38 : 0) + 18;
        notation.setBounds (r.getX(), y, r.getWidth(), 84);           y += 84 + 8;
        extra.setBounds (r.getX(), y, r.getWidth(), 26);              y += 26 + 10 + 18;
        profileBox.setBounds (r.getX(), y, r.getWidth(), 26);         y += 26 + 8;
        previewArea = { r.getX(), y, r.getWidth(), 66 };              y += 66 + 8;
        if (offer)
        {
            decompose.setBounds (r.getX(), y, r.getWidth() - 150, 24);
            decompBox.setBounds (r.getRight() - 140, y, 140, 24);
            y += 34;
        }
        okButton.setBounds (r.getRight() - 96, card.getBottom() - 44, 96, 30);
        cancelButton.setBounds (r.getRight() - 96 - 8 - 96, card.getBottom() - 44, 96, 30);
    }
}
