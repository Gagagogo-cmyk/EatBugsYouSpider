#include "CapturePanel.h"
#include "Theme.h"

namespace gnumbat::ui
{
    using juce::String;

    static const char* kModeNames[] = { "RANGE", "LAST BARS", "LOOP", "LAST SEC" };
    static const CapturePlan::Mode kModes[] = { CapturePlan::Mode::range, CapturePlan::Mode::lastBars, CapturePlan::Mode::loop, CapturePlan::Mode::lastSeconds };

    static double beatsPerBar (const TransportSnapshot& t) { return t.tsNum > 0 && t.tsDen > 0 ? t.tsNum * 4.0 / t.tsDen : 4.0; }

    String CapturePanel::formatMarker (const Marker& m, const TransportSnapshot& t)
    {
        if (! m.isSet()) return "-";
        if (m.hasPpq && t.hasPpq)
        {
            const double bpb = beatsPerBar (t);
            const int bar = (int) std::floor (m.ppq / bpb) + 1;
            const double beat = std::fmod (m.ppq, bpb) + 1.0;
            return String (bar) + "|" + String (beat < 0 ? beat + bpb : beat, 2);
        }
        const double secs = t.sampleRate > 0 ? (double) m.sample / t.sampleRate : 0.0;
        const int mm = (int) (secs / 60.0);
        return String (mm) + ":" + String::formatted ("%06.3f", secs - mm * 60.0);
    }

    bool CapturePanel::parseMarker (const String& text, const Marker& now, const TransportSnapshot& t, Marker& out)
    {
        const auto s = text.trim();
        if (s.isEmpty() || ! now.isSet() || t.sampleRate <= 0) return false;
        if (s.containsChar ('|'))                                // bar|beat  (1-based), relative to "now" at constant tempo
        {
            if (! now.hasPpq || t.bpm <= 0) return false;
            const double bpb = beatsPerBar (t);
            const double bar = s.upToFirstOccurrenceOf ("|", false, false).getDoubleValue();
            const double beat = s.fromFirstOccurrenceOf ("|", false, false).getDoubleValue();
            const double ppq = (bar - 1.0) * bpb + (beat - 1.0);
            out.ppq = ppq; out.hasPpq = true;
            out.sample = now.sample + (juce::int64) std::llround ((ppq - now.ppq) * 60.0 / t.bpm * t.sampleRate);
            return out.sample >= 0;
        }
        double secs = 0.0;                                       // m:ss.mmm | ss.mmm
        if (s.containsChar (':')) secs = s.upToFirstOccurrenceOf (":", false, false).getDoubleValue() * 60.0 + s.fromFirstOccurrenceOf (":", false, false).getDoubleValue();
        else secs = s.getDoubleValue();
        if (secs < 0) return false;
        out.sample = (juce::int64) std::llround (secs * t.sampleRate);
        out.hasPpq = now.hasPpq && t.bpm > 0;
        if (out.hasPpq) out.ppq = now.ppq + (double) (out.sample - now.sample) / t.sampleRate * t.bpm / 60.0;
        return true;
    }

    CapturePanel::CapturePanel (GnumbatProcessor& p, UiHost& h) : proc (p), host (h)
    {
        for (int i = 0; i < 4; ++i)
        {
            modeButtons[i].setButtonText (kModeNames[i]);
            modeButtons[i].setClickingTogglesState (false);
            modeButtons[i].onClick = [this, i] { selectMode (kModes[i]); };
            addAndMakeVisible (modeButtons[i]);
        }
        modeButtons[0].setTooltip ("Play the range in the host once; whatever passed through the plugin between IN and OUT is captured.");
        modeButtons[1].setTooltip ("The last N bars that passed through the plugin (uses the host tempo and time signature).");
        modeButtons[2].setTooltip ("The host loop range (needs a host that reports loop points; tempo changes inside the loop make the edges approximate).");
        modeButtons[3].setTooltip ("The last N seconds that passed through the plugin.");

        setIn.onClick = [this] { proc.plan.in = proc.markerNow(); };
        setOut.onClick = [this] { proc.plan.out = proc.markerNow(); };
        inMinus.onClick = [this] { nudge (proc.plan.in, -1, juce::ModifierKeys::currentModifiers.isShiftDown()); };
        inPlus.onClick = [this] { nudge (proc.plan.in, +1, juce::ModifierKeys::currentModifiers.isShiftDown()); };
        outMinus.onClick = [this] { nudge (proc.plan.out, -1, juce::ModifierKeys::currentModifiers.isShiftDown()); };
        outPlus.onClick = [this] { nudge (proc.plan.out, +1, juce::ModifierKeys::currentModifiers.isShiftDown()); };
        for (auto* b : { &inMinus, &inPlus, &outMinus, &outPlus }) b->setTooltip ("nudge by a beat (Shift: a bar)");
        for (auto* b : { &setIn, &setOut, &inMinus, &inPlus, &outMinus, &outPlus }) addAndMakeVisible (*b);

        for (auto* e : { &inEdit, &outEdit, &barsEdit, &secsEdit }) { e->setFont (mono (13.0f)); e->setJustification (juce::Justification::centred); addAndMakeVisible (*e); }
        inEdit.setTooltip ("type  m:ss.mmm  or  bar|beat  and press Enter");
        outEdit.setTooltip ("type  m:ss.mmm  or  bar|beat  and press Enter");
        inEdit.onReturnKey = [this] { commitEdit (true); };   inEdit.onFocusLost = [this] { commitEdit (true); };
        outEdit.onReturnKey = [this] { commitEdit (false); }; outEdit.onFocusLost = [this] { commitEdit (false); };
        barsEdit.setInputRestrictions (8, "0123456789.");
        secsEdit.setInputRestrictions (8, "0123456789.");
        barsEdit.onTextChange = [this] { proc.plan.bars = juce::jlimit (0.25, 512.0, barsEdit.getText().getDoubleValue()); };
        secsEdit.onTextChange = [this] { proc.plan.seconds = juce::jlimit (0.1, 900.0, secsEdit.getText().getDoubleValue()); };

        bake.setColour (juce::TextButton::buttonColourId, col::green.withAlpha (0.30f));
        bake.setColour (juce::TextButton::textColourOffId, col::green);
        bake.onClick = [this] { if (onBake) onBake(); };
        import_.onClick = [this] { if (onImport) onImport(); };
        bake.setTooltip ("Capture, name and store a Bake. Audio is copied out of the ring first, so you can take your time typing.");
        addAndMakeVisible (bake);
        addAndMakeVisible (import_);
        refreshFromPlan();
        startTimerHz (15);
    }

    CapturePanel::~CapturePanel() { stopTimer(); }

    void CapturePanel::refreshFromPlan()
    {
        barsEdit.setText (String (proc.plan.bars, 2).trimCharactersAtEnd ("0").trimCharactersAtEnd ("."), false);
        secsEdit.setText (String (proc.plan.seconds, 1), false);
        layoutForMode();
    }

    void CapturePanel::selectMode (CapturePlan::Mode m) { proc.plan.mode = m; layoutForMode(); repaint(); }

    void CapturePanel::nudge (Marker& m, int dir, bool bar)
    {
        if (! m.isSet()) return;
        const double beats = (bar ? beatsPerBar (t) : 1.0) * dir;
        m.sample = juce::jmax<juce::int64> (0, m.sample + proc.samplesForBeats (beats));
        if (m.hasPpq) m.ppq += beats;
    }

    void CapturePanel::commitEdit (bool isIn)
    {
        auto& e = isIn ? inEdit : outEdit;
        auto& target = isIn ? proc.plan.in : proc.plan.out;
        if (e.getText() == (isIn ? lastInText : lastOutText)) return;
        Marker m;
        if (parseMarker (e.getText(), proc.markerNow(), proc.transport(), m)) target = m;
        else host.notify ("could not read that position (use m:ss.mmm or bar|beat; bar|beat needs the host's tempo)", true);
    }

    void CapturePanel::layoutForMode()
    {
        const auto m = proc.plan.mode;
        const bool range = m == CapturePlan::Mode::range;
        for (auto* c : std::initializer_list<juce::Component*> { &setIn, &setOut, &inMinus, &inPlus, &outMinus, &outPlus, &inEdit, &outEdit }) c->setVisible (range);
        barsEdit.setVisible (m == CapturePlan::Mode::lastBars);
        secsEdit.setVisible (m == CapturePlan::Mode::lastSeconds);
        for (int i = 0; i < 4; ++i) modeButtons[i].setToggleState (kModes[i] == m, juce::dontSendNotification);
        resized();
    }

    void CapturePanel::resized()
    {
        auto r = getLocalBounds().reduced (8, 6);
        auto row1 = r.removeFromTop (22);
        meterRect = row1.removeFromRight (120);
        hostRect = row1;
        r.removeFromTop (6);
        auto row2 = r.removeFromTop (28);
        for (int i = 0; i < 4; ++i) { modeButtons[i].setBounds (row2.removeFromLeft (i == 1 ? 92 : 78)); row2.removeFromLeft (2); }
        row2.removeFromLeft (14);
        bake.setBounds (row2.removeFromRight (110));
        row2.removeFromRight (6);
        import_.setBounds (row2.removeFromRight (100));
        row2.removeFromRight (10);
        const auto m = proc.plan.mode;
        if (m == CapturePlan::Mode::range)
        {
            row2.removeFromLeft (26);                                    // "IN" label
            inMinus.setBounds (row2.removeFromLeft (22));  inEdit.setBounds (row2.removeFromLeft (86));  inPlus.setBounds (row2.removeFromLeft (22));
            row2.removeFromLeft (2);  setIn.setBounds (row2.removeFromLeft (58));
            row2.removeFromLeft (20);
            row2.removeFromLeft (34);                                    // "OUT" label
            outMinus.setBounds (row2.removeFromLeft (22)); outEdit.setBounds (row2.removeFromLeft (86)); outPlus.setBounds (row2.removeFromLeft (22));
            row2.removeFromLeft (2);  setOut.setBounds (row2.removeFromLeft (64));
        }
        else if (m == CapturePlan::Mode::lastBars) { row2.removeFromLeft (44); barsEdit.setBounds (row2.removeFromLeft (64)); }
        else if (m == CapturePlan::Mode::lastSeconds) { row2.removeFromLeft (44); secsEdit.setBounds (row2.removeFromLeft (64)); }
        r.removeFromTop (6);
        coverageRect = r.removeFromTop (16);
    }

    void CapturePanel::timerCallback()
    {
        t = proc.transport();
        // coverage of the current definition
        Marker a, b;
        double cov = 0.0;
        const auto m = proc.plan.mode;
        if (m == CapturePlan::Mode::range) cov = proc.coverageOf (proc.plan.in, proc.plan.out);
        else if (m == CapturePlan::Mode::loop) cov = proc.loopMarkers (a, b) ? proc.coverageOf (a, b) : 0.0;
        else
        {
            const double bpm = t.bpm > 0 ? t.bpm : 120.0;
            const double secs = m == CapturePlan::Mode::lastBars ? proc.plan.bars * beatsPerBar (t) * 60.0 / bpm : proc.plan.seconds;
            const double have = t.sampleRate > 0 ? juce::jmin ((double) t.written, (double) proc.ring().usableSamples()) / t.sampleRate : 0.0;
            cov = secs > 0 ? juce::jmin (1.0, have / secs) : 0.0;
        }
        coverage = cov;

        // keep the editors in sync with the plan unless the user is typing in them
        auto sync = [this] (juce::TextEditor& e, const Marker& mk, String& last)
        {
            const auto txt = formatMarker (mk, t);
            if (! e.hasKeyboardFocus (true) && txt != last) { e.setText (txt, false); last = txt; }
        };
        sync (inEdit, proc.plan.in, lastInText);
        sync (outEdit, proc.plan.out, lastOutText);
        repaint();
    }

    void CapturePanel::paint (juce::Graphics& g)
    {
        g.fillAll (col::panel);
        g.setColour (col::line);  g.drawHorizontalLine (getHeight() - 1, 0.0f, (float) getWidth());

        // ---- host line
        auto hr = hostRect;
        g.setFont (mono (12.0f));
        const bool live = t.valid;
        const bool playing = t.playing;
        g.setColour (! live ? col::dim : playing ? col::green : col::amber);
        g.fillEllipse ((float) hr.getX(), (float) hr.getCentreY() - 4.0f, 8.0f, 8.0f);
        hr.removeFromLeft (16);
        String s;
        s << (! live ? "IDLE (nothing processed yet)" : proc.isStandalone() ? "STANDALONE" : playing ? "PLAYING" : "STOPPED");
        s << "   " << proc.hostName();
        if (proc.trackName().isNotEmpty()) s << " / " << proc.trackName();
        if (t.bpm > 0) s << "   " << String (t.bpm, 1) << " bpm";
        if (t.tsNum > 0) s << "  " << t.tsNum << "/" << t.tsDen;
        if (live && t.samples >= 0)
        {
            Marker now; now.sample = t.samples; now.ppq = t.ppq; now.hasPpq = t.hasPpq;
            s << "   pos " << formatMarker (now, t);
        }
        if (live && ! t.hostTimeline) s << "   (no host timeline: own counter)";
        if (t.offline) s << "   OFFLINE";
        if (t.recording) s << "   REC";
        g.setColour (col::text);
        g.drawText (s, hr, juce::Justification::centredLeft, true);

        // ---- meters
        for (int c = 0; c < 2; ++c)
        {
            auto m = meterRect.removeFromTop (8).reduced (0, 0);
            meterRect.removeFromTop (2);
            g.setColour (col::bg); g.fillRect (m);
            const double db = juce::Decibels::gainToDecibels (t.level[c], -60.0);
            const float f = (float) juce::jlimit (0.0, 1.0, (db + 60.0) / 60.0);
            g.setColour (db > -1.0 ? col::red : db > -12.0 ? col::amber : col::green);
            g.fillRect (m.withWidth ((int) ((float) m.getWidth() * f)));
        }

        // ---- labels for row 2
        g.setFont (mono (11.0f)); g.setColour (col::dim);
        if (proc.plan.mode == CapturePlan::Mode::range)
        {
            g.drawText ("IN",  inMinus.getX() - 26, inMinus.getY(), 24, inMinus.getHeight(), juce::Justification::centredRight);
            g.drawText ("OUT", outMinus.getX() - 34, outMinus.getY(), 32, outMinus.getHeight(), juce::Justification::centredRight);
            if (proc.plan.in.isSet() && proc.plan.out.isSet() && t.sampleRate > 0)
            {
                const double len = (double) (proc.plan.out.sample - proc.plan.in.sample) / t.sampleRate;
                g.setColour (len > 0 ? col::text : col::red);
                g.drawText (len > 0 ? String (len, 2) + " s" : String ("OUT before IN"), outPlus.getRight() + 70, outPlus.getY(), 120, outPlus.getHeight(), juce::Justification::centredLeft);
            }
        }
        else if (proc.plan.mode == CapturePlan::Mode::lastBars) g.drawText ("bars", barsEdit.getRight() + 6, barsEdit.getY(), 60, barsEdit.getHeight(), juce::Justification::centredLeft);
        else if (proc.plan.mode == CapturePlan::Mode::lastSeconds) g.drawText ("seconds", secsEdit.getRight() + 6, secsEdit.getY(), 80, secsEdit.getHeight(), juce::Justification::centredLeft);
        else
        {
            Marker a, b;
            const bool ok = proc.loopMarkers (a, b);
            g.setColour (ok ? col::text : col::amber);
            g.drawText (ok ? "host loop  " + formatMarker (a, t) + "  ->  " + formatMarker (b, t) : String ("the host is not reporting a loop range"),
                        modeButtons[3].getRight() + 16, modeButtons[3].getY(), 480, modeButtons[3].getHeight(), juce::Justification::centredLeft);
        }

        // ---- coverage bar
        g.setColour (col::bg);   g.fillRect (coverageRect);
        g.setColour (col::line); g.drawRect (coverageRect, 1);
        g.setColour ((coverage >= 0.999 ? col::green : col::amber).withAlpha (0.55f));
        g.fillRect (coverageRect.reduced (1).withWidth ((int) ((double) (coverageRect.getWidth() - 2) * coverage)));
        g.setColour (col::text); g.setFont (mono (10.5f));
        String cv = "heard " + String (juce::roundToInt (coverage * 100.0)) + " %";
        if (proc.plan.mode == CapturePlan::Mode::range && coverage < 0.999) cv << "  -  play the range through the plugin to capture it";
        if (proc.plan.mode != CapturePlan::Mode::range && coverage < 0.999) cv << "  -  not enough audio has passed through yet";
        g.drawText (cv, coverageRect.reduced (6, 0), juce::Justification::centredLeft);
        g.setColour (col::dim);
        g.drawText ("ring " + String ((double) proc.ring().usableSamples() / juce::jmax (1.0, t.sampleRate), 0) + " s", coverageRect.reduced (6, 0), juce::Justification::centredRight);
    }
}
