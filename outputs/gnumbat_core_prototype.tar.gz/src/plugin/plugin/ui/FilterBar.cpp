#include "FilterBar.h"
#include "../../core/JsonIo.h"

namespace gnumbat::ui
{
    using juce::String;
    using juce::var;

    FilterBar::FilterBar (AppModel& m, UiHost& h) : model (m), host (h)
    {
        search.setFont (mono (12.5f));
        search.setTextToShowWhenEmpty ("/ search id, notation, tags, groups, fields ...", col::dim);
        search.setText (m.search(), false);
        search.addListener (this);
        search.onEscapeKey = [this] { search.clear(); model.setSearch ({}); };
        addAndMakeVisible (search);
        addButton.onClick = [this] { showBuilder(); };
        clearButton.onClick = [this] { search.clear(); model.setSearch ({}); model.setChips ({}); };
        addAndMakeVisible (addButton);
        addAndMakeVisible (clearButton);
        model.addChangeListener (this);
        updateCount();
    }

    FilterBar::~FilterBar() { model.removeChangeListener (this); }

    void FilterBar::updateCount()
    {
        countText = String ((int) model.visible().size()) + " / " + String ((int) model.rows().size());
    }

    void FilterBar::resizedIfChipsChanged()
    {
        if (lastChipCount != model.chips().size()) { lastChipCount = model.chips().size(); resized(); if (auto* p = getParentComponent()) p->resized(); }
    }

    static String chipText (const var& c)
    {
        auto t = filter::describe (c);
        return t.length() > 46 ? t.substring (0, 45) + "..." : t;
    }

    int FilterBar::heightForWidth (int w) const
    {
        int x = 0, rows = 1;
        for (auto& c : model.chips())
        {
            const int cw = juce::GlyphArrangement::getStringWidthInt (mono (11.5f), chipText (c)) + 30;
            if (x + cw > w) { ++rows; x = 0; }
            x += cw + 6;
        }
        return 32 + (model.chips().isEmpty() ? 0 : rows * 24 + 2);
    }

    void FilterBar::resized()
    {
        auto r = getLocalBounds();
        auto top = r.removeFromTop (30);
        clearButton.setBounds (top.removeFromRight (64));
        top.removeFromRight (4);
        addButton.setBounds (top.removeFromRight (84));
        top.removeFromRight (70);            // count text
        top.removeFromRight (4);
        search.setBounds (top);
        chipRects.clear();
        int x = 0, y = 32;
        for (int i = 0; i < model.chips().size(); ++i)
        {
            const int cw = juce::GlyphArrangement::getStringWidthInt (mono (11.5f), chipText (model.chips()[i])) + 30;
            if (x + cw > getWidth()) { x = 0; y += 24; }
            chipRects.push_back ({ { x, y, cw, 21 }, i });
            x += cw + 6;
        }
    }

    void FilterBar::paint (juce::Graphics& g)
    {
        g.setColour (col::dim);
        g.setFont (mono (11.5f));
        g.drawText (countText, getWidth() - 64 - 4 - 84 - 4 - 70, 0, 66, 30, juce::Justification::centredRight);
        for (auto& [rect, idx] : chipRects)
        {
            g.setColour (col::panelHi);  g.fillRect (rect);
            g.setColour (col::cyan.withAlpha (0.6f)); g.drawRect (rect, 1);
            g.setColour (col::text);     g.setFont (mono (11.5f));
            g.drawText (chipText (model.chips()[idx]), rect.withTrimmedLeft (8).withTrimmedRight (22), juce::Justification::centredLeft, true);
            g.setColour (col::dim);
            g.drawText ("x", rect.removeFromRight (20), juce::Justification::centred);
        }
    }

    void FilterBar::mouseUp (const juce::MouseEvent& e)
    {
        for (auto& [rect, idx] : chipRects)
            if (rect.contains (e.getPosition()))
            {
                auto chips = model.chips();
                chips.remove (idx);
                model.setChips (chips);
                return;
            }
    }

    // ---- builder ----------------------------------------------------------------------------------------------
    static juce::Array<filter::FieldInfo> catalogFor (AppModel& m)
    {
        auto cat = filter::catalog (m.allViews());
        // hide plumbing that is never a useful filter target
        juce::Array<filter::FieldInfo> out;
        for (auto& f : cat)
            if (! f.path.startsWith ("analysis/summary/") || f.path.endsWith ("/mean")) out.add (f);
        return out;
    }

    void FilterBar::showBuilder()
    {
        auto cat = catalogFor (model);
        juce::PopupMenu menu;
        juce::PopupMenu fieldsMenu, analysisMenu, captureMenu, otherMenu;
        static const juce::StringArray primary { "state", "tags", "groups", "notation", "datasets", "models", "origin", "duration_s" };
        int id = 1;
        for (auto& f : cat)
        {
            const bool isPrimary = primary.contains (f.path);
            auto label = f.path.replace ("analysis/summary/mix/", "").replace ("/mean", "") + "   " + f.types.joinIntoString ("|");
            if (f.hasRange) label << "  [" << String (f.min, 2) << " .. " << String (f.max, 2) << "]";
            auto& target = isPrimary ? menu : f.path.startsWith ("fields/") ? fieldsMenu : f.path.startsWith ("analysis/") ? analysisMenu : f.path.startsWith ("capture/") ? captureMenu : otherMenu;
            target.addItem (id, isPrimary ? f.path + "   " + f.types.joinIntoString ("|") : label);
            ++id;
        }
        menu.addSeparator();
        if (fieldsMenu.getNumItems())   menu.addSubMenu ("fields  (from notation profiles / user)", fieldsMenu);
        if (analysisMenu.getNumItems()) menu.addSubMenu ("analysis  (mix means)", analysisMenu);
        if (captureMenu.getNumItems())  menu.addSubMenu ("capture  (host facts)", captureMenu);
        if (otherMenu.getNumItems())    menu.addSubMenu ("other", otherMenu);
        if (cat.isEmpty()) menu.addItem (-1, "(no Bakes yet)", false);

        menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&addButton).withMinimumWidth (300), [this, cat] (int r)
        {
            if (r >= 1 && r <= cat.size()) chooseOperator (cat[r - 1]);
        });
    }

    void FilterBar::chooseOperator (const filter::FieldInfo& f)
    {
        juce::PopupMenu m;
        const bool num = f.types.contains ("number"), list = f.types.contains ("list");
        struct Op { const char* op; const char* label; };
        std::vector<Op> ops;
        if (num) ops = std::vector<Op> { { "gte", ">=" }, { "lte", "<=" }, { "gt", ">" }, { "lt", "<" }, { "between", "between" }, { "eq", "=" } };
        else if (list) ops = std::vector<Op> { { "has", "has" }, { "contains", "contains text" }, { "in", "any of" } };
        else ops = std::vector<Op> { { "eq", "is" }, { "ne", "is not" }, { "contains", "contains" }, { "prefix", "starts with" }, { "in", "any of" } };
        int id = 1;
        for (auto& o : ops) m.addItem (id++, o.label);
        m.addSeparator();
        m.addItem (100, "exists");
        m.addItem (101, "does not exist");
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&addButton), [this, f, ops] (int r)
        {
            if (r == 100 || r == 101)
            {
                auto chips = model.chips();
                chips.add (filter::leaf (f.path, "exists", r == 100));
                model.setChips (chips);
            }
            else if (r >= 1 && r <= (int) ops.size()) askValue (f, ops[(size_t) r - 1].op);
        });
    }

    void FilterBar::askValue (const filter::FieldInfo& f, const String& op)
    {
        juce::Array<PromptField> fields;
        String hint = f.topValues.isEmpty() ? String() : "e.g. " + f.topValues.joinIntoString (", ");
        if (op == "between") { fields.add ({ "FROM", f.hasRange ? String (f.min) : String(), "", false }); fields.add ({ "TO", f.hasRange ? String (f.max) : String(), "", false }); }
        else if (op == "in") fields.add ({ "ANY OF (comma separated)", "", hint, false });
        else fields.add ({ f.path.toUpperCase() + " " + op.toUpperCase(), "", hint, false });

        host.prompt ("Add filter", f.path, fields, "ADD", [this, f, op] (juce::StringArray v)
        {
            auto asVar = [&f] (const String& s) -> var
            {
                const auto t = s.trim();
                if (f.types.contains ("number") && (t.containsOnly ("0123456789.-+eE") && t.isNotEmpty())) return t.getDoubleValue();
                if (t.equalsIgnoreCase ("true") && f.types.contains ("bool")) return true;
                if (t.equalsIgnoreCase ("false") && f.types.contains ("bool")) return false;
                return t;
            };
            var value;
            if (op == "between") value = var (juce::Array<var> { asVar (v[0]), asVar (v[1]) });
            else if (op == "in")
            {
                juce::Array<var> items;
                for (auto& t : juce::StringArray::fromTokens (v[0], ",", "")) if (t.trim().isNotEmpty()) items.add (asVar (t));
                value = var (items);
            }
            else value = asVar (v[0]);
            auto node = filter::leaf (f.path, op, value);
            if (auto err = filter::validate (node); err.isNotEmpty()) { host.notify (err, true); return; }
            auto chips = model.chips();
            chips.add (node);
            model.setChips (chips);
        });
    }
}
