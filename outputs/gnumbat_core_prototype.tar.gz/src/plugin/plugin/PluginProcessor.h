#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <atomic>
#include "../core/CaptureBuffer.h"
#include "../core/Library.h"

namespace gnumbat
{
    /** A position the user marked on the host timeline. Samples are host timeline samples (or, in a host
        that reports no timeline, the plugin's own running sample counter). PPQ is kept when the host gave it. */
    struct Marker
    {
        juce::int64 sample = -1;
        double ppq = 0.0;
        bool hasPpq = false;
        bool isSet() const noexcept { return sample >= 0; }
    };

    struct CapturePlan
    {
        enum class Mode { range, lastBars, loop, lastSeconds };
        Mode mode = Mode::lastBars;
        Marker in, out;
        double bars = 4.0;
        double seconds = 10.0;
        static const char* modeName (Mode m) { return m == Mode::range ? "range" : m == Mode::lastBars ? "last_bars" : m == Mode::loop ? "loop" : "last_seconds"; }
    };

    /** Everything the UI needs to know about the host transport. Written by the audio thread, read by the UI
        (individual atomics: the UI tolerates a value or two being from adjacent blocks). */
    struct TransportSnapshot
    {
        bool valid = false;               // the plugin has processed at least one block
        bool hostTimeline = false;        // false => timeline is the plugin's own running counter (standalone / hosts without a playhead)
        bool playing = false, recording = false, looping = false, offline = false, hasLoop = false;
        juce::int64 samples = -1;         // current timeline position
        bool hasPpq = false;  double ppq = 0.0;
        double bpm = 0.0;     int tsNum = 0, tsDen = 0;
        double loopStartPpq = 0.0, loopEndPpq = 0.0;
        double sampleRate = 0.0;
        juce::int64 written = 0;          // total samples pushed into the ring
        double level[2] = { 0.0, 0.0 };   // recent peak per channel, linear
    };

    struct PreparedCapture
    {
        bool ok = false;
        juce::String problem;             // why not ok
        NewBake bake;                     // audio + capture meta filled in; notation is added by the caller
        double coverage = 0.0;            // fraction of the requested span that was actually heard
        double seconds = 0.0;
        juce::String summary;             // "8.00 s · bars 17–21 · 100 %"
    };

    class GnumbatProcessor final : public juce::AudioProcessor
    {
    public:
        GnumbatProcessor();
        ~GnumbatProcessor() override = default;

        // ---- AudioProcessor
        void prepareToPlay (double sampleRate, int samplesPerBlock) override;
        void releaseResources() override {}
        bool isBusesLayoutSupported (const BusesLayout&) const override;
        void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
        using AudioProcessor::processBlock;
        juce::AudioProcessorEditor* createEditor() override;
        bool hasEditor() const override { return true; }
        const juce::String getName() const override { return "Gnumbat"; }
        bool acceptsMidi() const override { return false; }
        bool producesMidi() const override { return false; }
        double getTailLengthSeconds() const override { return 0.0; }
        int getNumPrograms() override { return 1; }
        int getCurrentProgram() override { return 0; }
        void setCurrentProgram (int) override {}
        const juce::String getProgramName (int) override { return {}; }
        void changeProgramName (int, const juce::String&) override {}
        void getStateInformation (juce::MemoryBlock&) override;
        void setStateInformation (const void*, int) override;
        void updateTrackProperties (const TrackProperties&) override;

        // ---- for the UI (message thread)
        TransportSnapshot transport() const;
        juce::String hostName() const;
        juce::String trackName() const;
        bool isStandalone() const { return wrapperType == wrapperType_Standalone; }
        const CaptureBuffer& ring() const noexcept { return capture; }

        /** Take a snapshot of the audio the plan describes. Copies out of the ring; call on the message thread. */
        PreparedCapture prepareCapture (const CapturePlan&) const;

        /** Marker at the current transport position (unset if nothing has been processed yet). */
        Marker markerNow() const;
        /** Convert a bar count / beat count to samples with the current tempo (constant-tempo assumption). */
        juce::int64 samplesForBeats (double beats) const;
        /** Host loop range as markers (approximate under tempo changes); false if the host has no loop. */
        bool loopMarkers (Marker& start, Marker& end) const;
        /** Fraction of [in,out] that has been heard (0..1); the coverage bar in the UI. */
        double coverageOf (const Marker& in, const Marker& out) const;

        // ---- persisted UI/session state (JSON object). Audio itself is never persisted.
        CapturePlan plan;
        juce::var uiState() const;
        void setUiState (const juce::String& key, const juce::var& value);
        juce::var getUiState (const juce::String& key, const juce::var& fallback = {}) const;

        static constexpr int kMaxCaptureChannels = 2;

    private:
        CaptureBuffer capture;
        double preparedRate = 0.0;
        int preparedChannels = 0;
        double preparedRing = 0.0;
        double ringSeconds = 120.0;
        const juce::String sessionId;

        // audio-thread -> UI mailbox
        std::atomic<bool> tValid { false }, tHostTimeline { false }, tPlaying { false }, tRecording { false }, tLooping { false }, tOffline { false }, tHasLoop { false }, tHasPpq { false };
        std::atomic<juce::int64> tSamples { -1 };
        std::atomic<double> tPpq { 0.0 }, tBpm { 0.0 }, tLoopStart { 0.0 }, tLoopEnd { 0.0 }, tSampleRate { 0.0 };
        std::atomic<int> tNum { 0 }, tDen { 0 };
        std::atomic<float> level[2] { { 0.0f }, { 0.0f } };
        juce::int64 ownTimeline = 0;                    // audio thread only

        mutable juce::CriticalSection metaLock;         // message thread only
        juce::String track;
        juce::var ui = juce::var (new juce::DynamicObject());

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GnumbatProcessor)
    };
}
